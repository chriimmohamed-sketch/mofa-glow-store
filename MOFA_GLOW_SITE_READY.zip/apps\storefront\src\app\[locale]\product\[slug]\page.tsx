import { isLocale, getMessages } from "@/lib/i18n";
import { fetchProducts, fetchProductBySlug } from "@/lib/data";
import { formatMAD } from "@/lib/money";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";
import { notFound } from "next/navigation";

export default async function ProductPage({ params }: { params: Promise<{ locale: string; slug: string }> }) {
  const { locale, slug } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  const p = await fetchProductBySlug(slug);
  if (!p) notFound();
  const allProducts = await fetchProducts();
  const related = allProducts.filter((x) => x.category === p.category && x.id !== p.id).slice(0, 3);

  return (
    <>
      <Header locale={l} messages={m} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-10 sm:py-14">
        {/* Breadcrumb */}
        <nav className="text-xs text-[#242424]/60 mb-8 flex flex-wrap gap-2 items-center">
          <Link href={`/${l}`} className="hover:text-[#B38A4C] transition-colors">الرئيسية</Link>
          <span>/</span>
          <Link href={`/${l}/shop`} className="hover:text-[#B38A4C] transition-colors">المتجر</Link>
          <span>/</span>
          <span className="text-[#242424]">{p.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
          {/* Product Gallery */}
          <div>
            <div className="relative rounded-3xl overflow-hidden border border-[#D9C7AD]/70 bg-[#F3EBDD] shadow-[0_20px_50px_-20px_rgba(36,36,36,0.08)]">
              <img src={p.images[0]} alt={p.name} className="w-full aspect-square object-cover" />
            </div>
            {p.images.length > 1 && (
              <div className="grid grid-cols-4 gap-3 mt-4">
                {p.images.map((img, i) => (
                  <div key={i} className={`rounded-2xl overflow-hidden border ${i === 0 ? "border-2 border-[#B38A4C]/60" : "border border-[#D9C7AD]/70"} bg-[#FAF7F2]`}>
                    <img src={img} alt={`${p.name} view ${i + 1}`} className="w-full aspect-square object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <p className="tracking-[0.2em] text-[#B9A18D] uppercase text-xs mb-2">{p.categoryLabel} • {p.volume}</p>
              <h1 className="font-serif text-3xl sm:text-4xl text-[#242424] leading-snug">{p.name}</h1>
              <p className="text-sm text-[#B9A18D] tracking-wider mt-1">{p.nameFr}</p>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="font-serif text-4xl font-bold text-[#242424]">{formatMAD(p.price, l)}</span>
              <span className="text-xs px-2.5 py-1 rounded-full bg-[#F3EBDD] border border-[#D9C7AD] text-[#242424]/70">
                {p.badge}
              </span>
            </div>

            <p className="text-[#242424]/75 leading-relaxed">{p.description}</p>

            {p.ingredients.length > 0 && (
              <div className="space-y-2 border-y border-[#D9C7AD]/50 py-4">
                <h4 className="text-xs font-bold text-[#242424] mb-2">المكونات النشطة الرئيسية:</h4>
                <div className="flex flex-wrap gap-2">
                  {p.ingredients.map((ing) => (
                    <span key={ing} className="text-xs px-3 py-1 rounded-full bg-[#F3EBDD] border border-[#D9C7AD]/70 text-[#242424]/85">
                      {ing}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {p.ritual && (
              <div>
                <h4 className="text-xs font-bold text-[#242424] mb-1">طريقة الاستخدام المثالية:</h4>
                <p className="text-xs text-[#242424]/75 leading-relaxed">{p.ritual}</p>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button className="flex-1 py-4 px-6 rounded-full bg-[#242424] text-[#FAF7F2] text-sm font-medium hover:bg-[#242424]/90 transition-all shadow-md">
                أضيفي للحقيبة — {formatMAD(p.price, l)}
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 pt-4">
              {[
                ["توصيل سريع", "24–48 ساعة"],
                ["الدفع عند الاستلام", "متاح"],
                ["إرجاع سهل", "وفق سياسة"],
              ].map(([title, sub]) => (
                <div key={title} className="text-center p-3 rounded-2xl bg-[#F3EBDD]/60 border border-[#D9C7AD]/40">
                  <p className="text-xs font-bold text-[#242424]">{title}</p>
                  <p className="text-[10px] text-[#242424]/60 mt-0.5">{sub}</p>
                </div>
              ))}
            </div>

            <div className="text-xs text-[#242424]/60 pt-2">
              <p><strong>SKU:</strong> {p.sku}</p>
              <p><strong>الحجم:</strong> {p.volume}</p>
              <p><strong>التوفر:</strong> {p.inStock ? "متوفر" : "غير متوفر"}</p>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <section className="mt-20 sm:mt-24">
            <div className="flex items-end justify-between mb-8 gap-4">
              <div>
                <span className="tracking-[0.25em] text-[#B9A18D] uppercase text-xs block mb-2">YOU MAY ALSO LIKE</span>
                <h2 className="font-serif text-2xl sm:text-3xl text-[#242424]">منتجات ذات صلة</h2>
              </div>
              <Link href={`/${l}/shop`} className="text-xs text-[#242424]/60 hover:text-[#B38A4C] underline underline-offset-4">
                عرض الكل
              </Link>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
              {related.map((r) => (
                <Link key={r.id} href={`/${l}/product/${r.slug}`} className="group bg-[#F3EBDD]/60 border border-[#D9C7AD]/70 rounded-3xl overflow-hidden flex flex-col justify-between transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_28px_60px_-18px_rgba(185,161,141,0.25)]">
                  <div className="relative bg-[#FAF7F2] overflow-hidden border-b border-[#D9C7AD]/40">
                    <div className="absolute top-3.5 inset-x-3.5 z-10 flex items-center justify-between gap-2">
                      <span className="px-3 py-1 rounded-full bg-[#FAF7F2]/90 backdrop-blur border border-[#D9C7AD] text-[11px] font-medium text-[#242424] shadow-sm">
                        {r.badge}
                      </span>
                    </div>
                    <div className="cursor-pointer aspect-square w-full overflow-hidden bg-[#F3EBDD]">
                      <img src={r.images[0]} alt={r.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105" />
                    </div>
                  </div>
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <p className="tracking-wider text-[#B38A4C] uppercase mb-1 font-medium text-[11px]">{r.nameFr}</p>
                      <h3 className="font-serif text-lg text-[#242424] leading-snug hover:text-[#B38A4C] transition-colors">{r.name}</h3>
                    </div>
                    <div className="flex items-end justify-between pt-2 border-t border-[#D9C7AD]/50">
                      <span className="text-xl font-serif font-bold text-[#242424]">{formatMAD(r.price, l)}</span>
                      <span className="text-[11px] text-[#242424]/60">{r.volume}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}
