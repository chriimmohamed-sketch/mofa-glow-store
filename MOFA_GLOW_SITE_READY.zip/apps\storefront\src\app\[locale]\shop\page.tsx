import { isLocale, getMessages } from "@/lib/i18n";
import { fetchProducts } from "@/lib/data";
import { formatMAD } from "@/lib/money";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";

const categoryLabels: Record<string, string> = {
  face: "العناية بالوجه",
  specialized: "علاجات متخصصة",
  personal: "العناية الشخصية",
  men: "إصدار الرجال",
};

export default async function Shop({ params, searchParams }: { params: Promise<{ locale: string }>; searchParams: Promise<{ category?: string }> }) {
  const { locale } = await params;
  const { category } = await searchParams;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);

  const products = await fetchProducts();
  const categories = Array.from(new Set(products.map((p) => p.category)));
  const filtered = products.filter((p) => !category || p.category === category);

  return (
    <>
      <Header locale={l} messages={m} />
      <main>
        <section className="bg-[#F3EBDD]/80 border-b border-[#D9C7AD]/50 py-14 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
            <span className="tracking-[0.25em] text-[#B9A18D] uppercase text-xs block mb-2">THE COMPLETE APOTHECARY</span>
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#242424]">تشكيلة MOFA GLOW الحصرية</h1>
            <p className="text-sm text-[#242424]/70 mt-3 max-w-2xl">
              جميع العبوات أعيد تصميمها بالكامل بهوية MOFA GLOW الفاخرة. {products.length} تركيبات علاجية وتجميلية بأسعار شفافة.
            </p>
          </div>
        </section>

        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-8">
          <div className="flex items-center gap-2.5 overflow-x-auto pb-4 mb-6">
            <Link
              href={`/${l}/shop`}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${!category ? "bg-[#242424] text-[#FAF7F2] shadow-sm" : "bg-[#F3EBDD] text-[#242424] border border-[#D9C7AD]/70 hover:border-[#242424]"}`}
            >
              جميع المنتجات ({products.length})
            </Link>
            {categories.map((cat) => (
              <Link
                key={cat}
                href={`/${l}/shop?category=${encodeURIComponent(cat)}`}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${category === cat ? "bg-[#242424] text-[#FAF7F2] shadow-sm" : "bg-[#F3EBDD] text-[#242424] border border-[#D9C7AD]/70 hover:border-[#242424]"}`}
              >
                {categoryLabels[cat] || cat}
              </Link>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-7">
            {filtered.map((p) => (
              <Link
                key={p.id}
                href={`/${l}/product/${p.slug}`}
                className="group bg-[#F3EBDD]/60 border border-[#D9C7AD]/70 rounded-3xl overflow-hidden flex flex-col justify-between transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_28px_60px_-18px_rgba(185,161,141,0.25)]"
              >
                <div className="relative bg-[#FAF7F2] overflow-hidden border-b border-[#D9C7AD]/40">
                  <div className="absolute top-3.5 inset-x-3.5 z-10 flex items-center justify-between gap-2">
                    <span className="px-3 py-1 rounded-full bg-[#FAF7F2]/90 backdrop-blur border border-[#D9C7AD] text-[11px] font-medium text-[#242424] shadow-sm">
                      {p.badge}
                    </span>
                  </div>
                  <div className="cursor-pointer aspect-square w-full overflow-hidden bg-[#F3EBDD]">
                    <img src={p.images[0]} alt={p.name} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105" />
                  </div>
                  <div className="px-4 py-2.5 bg-[#FAF7F2]/90 backdrop-blur border-t border-[#D9C7AD]/40 flex items-center justify-between text-[11px] text-[#242424]/75">
                    <span className="tracking-wider uppercase font-medium">{p.volume}</span>
                  </div>
                </div>
                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <p className="tracking-wider text-[#B38A4C] uppercase mb-1 font-medium text-[11px]">{p.nameFr}</p>
                    <h3 className="font-serif text-xl text-[#242424] leading-snug hover:text-[#B38A4C] transition-colors">
                      {p.name}
                    </h3>
                    <p className="text-xs text-[#242424]/70 mt-2 leading-relaxed line-clamp-2">{p.subtitle}</p>
                  </div>
                  <div className="pt-3 border-t border-[#D9C7AD]/50 space-y-3">
                    <div className="flex items-end justify-between">
                      <div>
                        <span className="text-2xl font-serif font-bold text-[#242424]">{formatMAD(p.price, l)}</span>
                        <span className="text-xs font-medium text-[#242424]/80 mr-1">درهم</span>
                      </div>
                    </div>
                    <div className="w-full py-3 px-4 rounded-full bg-[#242424] text-[#FAF7F2] text-xs sm:text-sm font-medium flex items-center justify-center gap-2 shadow-sm">
                      <span>أضيفي إلى الحقيبة</span>
                      <span className="text-[#D9C7AD]">+</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16 bg-[#F3EBDD]/50 rounded-3xl border border-[#D9C7AD]/50 mt-8">
              <p className="font-serif text-2xl text-[#242424]">لم نجد منتجات مطابقة</p>
              <p className="text-sm text-[#242424]/65 mt-2">جربي البحث بكلمة أخرى أو استعرضي جميع المنتجات.</p>
            </div>
          )}
        </section>
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}
