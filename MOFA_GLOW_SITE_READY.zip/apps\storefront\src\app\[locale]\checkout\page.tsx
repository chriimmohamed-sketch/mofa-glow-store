import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";
import CheckoutClient from "@/components/CheckoutClient";

export default async function CheckoutPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <>
      <Header locale={l} messages={m} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-10 sm:py-14">
        <div className="mb-8">
          <span className="tracking-[0.25em] text-[#B9A18D] uppercase text-xs block mb-2">SECURE CHECKOUT</span>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#242424]">إتمام الطلب</h1>
          <p className="text-sm text-[#242424]/65 mt-2">الدفع عند الاستلام — نقداً عند توصيل طردكِ.</p>
        </div>
        <CheckoutClient locale={l} labels={{ shippingAddress: "معلومات التوصيل", cod: "الدفع عند الاستلام", online: "الدفع الإلكتروني", placeOrder: "تأكيد الطلب الآن", total: "الإجمالي" }} />
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}
