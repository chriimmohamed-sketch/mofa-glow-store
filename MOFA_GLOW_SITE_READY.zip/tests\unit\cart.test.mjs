import test from "node:test"; import assert from "node:assert/strict"; import { pathToFileURL } from "node:url";
const m = await import(pathToFileURL("C:/Users/Mohamed Chraim/Downloads/CHRAIM_Campus_Final/apps/storefront/src/lib/cart-math.ts").href);
test("lineTotal", () => assert.equal(m.lineTotal({productId:"p1",price:249.5,qty:2}), 499));
test("cartTotals", () => { const t=m.cartTotals([{productId:"p1",price:100,qty:2},{productId:"p2",price:50.25,qty:1}]); assert.equal(t.subtotal,250.25); assert.equal(t.total,250.25); });
test("with shipping/discount", () => assert.equal(m.cartTotals([{productId:"p1",price:300,qty:1}],30,20).total,310));
test("never negative", () => assert.equal(m.cartTotals([{productId:"p1",price:10,qty:1}],0,50).total,0));