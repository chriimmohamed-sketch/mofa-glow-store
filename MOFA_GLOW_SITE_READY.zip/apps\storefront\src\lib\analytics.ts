import { products } from "./products.ts";
import { profitMargin } from "./money.ts";

export interface CatalogMetrics {
  totalProducts: number;
  ownBrand: number;
  dropshipping: number;
  inStock: number;
  averageMargin: number;
  averageDeliveryDays: number;
  catalogValueMAD: number;
}

/**
 * These figures are computed from the CURRENT curated concept catalogue.
 * They are catalogue metrics, NOT sales or revenue figures.
 * Revenue/profit analytics require a live WooCommerce data source.
 */
export function catalogMetrics(): CatalogMetrics {
  const total = products.length;
  const margins = products.map((p) => profitMargin(p.price, p.cost));
  return {
    totalProducts: total,
    ownBrand: products.filter((p) => p.source === "OWN_BRAND").length,
    dropshipping: products.filter((p) => p.source === "DROPSHIPPING").length,
    inStock: products.filter((p) => p.inStock).length,
    averageMargin: margins.reduce((a, b) => a + b, 0) / (total || 1),
    averageDeliveryDays: products.reduce((a, p) => a + p.estimatedDeliveryDays, 0) / (total || 1),
    catalogValueMAD: products.reduce((a, p) => a + p.price * (p.inStock ? 1 : 0), 0),
  };
}

export const metricFormulas: Record<string, string> = {
  "Product profit": "Selling price − purchase cost (server-side)",
  "Product margin": "(Selling price − purchase cost) ÷ selling price",
  "Net order profit": "Sales − product costs − shipping − payment fees − other costs",
  "Catalog value": "Σ selling price for in-stock products (not revenue)",
};

