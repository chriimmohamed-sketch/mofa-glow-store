import type { MetadataRoute } from "next";
export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://mofaglow.ma";
  return { rules: { userAgent: "*", allow: "/", disallow: ["/account", "/api/", "/admin"] }, sitemap: `${base}/sitemap.xml` };
}