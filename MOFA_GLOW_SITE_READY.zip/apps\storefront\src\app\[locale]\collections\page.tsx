import { isLocale, getMessages } from "@/lib/i18n";
import { products } from "@/lib/products";
import { formatMAD } from "@/lib/money";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";

export default async function CollectionsPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  const cats = Array.from(new Set(products.map((p) => p.category)));
  return (
    <>
      <Header locale={l} messages={m} />
      <main className="container py-16">
        <div className="eyebrow mb-3">COLLECTIONS</div>
        <h1 className="font-display display-md mb-10">Explore by concern</h1>
        <div className="space-y-14">
          {cats.map((cat) => (
            <section key={cat}>
              <div className="flex items-end justify-between mb-5">
                <h2 className="font-display text-2xl capitalize">{cat}</h2>
                <span className="text-xs text-[var(--muted)]">{products.filter((p) => p.category === cat).length} products</span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
                {products.filter((p) => p.category === cat).map((p) => (
                  <Link key={p.id} href={`/${l}/product/${p.slug}`} className="card card-hover p-4">
                    <div className="media-frame aspect-square mb-4"><img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" /></div>
                    <div className="font-display text-lg mb-1">{p.name}</div>
                    <div className="price">{formatMAD(p.price, l)}</div>
                  </Link>
                ))}
              </div>
            </section>
          ))}
        </div>
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}