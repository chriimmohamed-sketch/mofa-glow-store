"use client";
import { useState } from "react";
import { useCart } from "@/lib/cart";
export default function AddToCartButton({ productId, slug, name, price, label }: { productId: string; slug: string; name: string; price: number; label: string }) {
  const { add } = useCart(); const [ok, setOk] = useState(false);
  return <button type="button" className="btn btn-primary" onClick={() => { add({ productId, slug, name, price }); setOk(true); setTimeout(() => setOk(false), 1500); }}>{ok ? "✓" : label}</button>;
}