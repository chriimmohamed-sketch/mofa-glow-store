import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";
import CartClient from "@/components/CartClient";

export default async function CartPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <>
      <Header locale={l} messages={m} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-10 sm:py-14">
        <div className="mb-8">
          <span className="tracking-[0.25em] text-[#B9A18D] uppercase text-xs block mb-2">YOUR SELECTION</span>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#242424]">حقيبة التسوق</h1>
        </div>
        <CartClient locale={l} labels={{ empty: "حقيبتكِ فارغة", remove: "حذف", subtotal: "المجموع الفرعي", shipping: "التوصيل", total: "الإجمالي", checkout: "إتمام الطلب" }} />
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}
