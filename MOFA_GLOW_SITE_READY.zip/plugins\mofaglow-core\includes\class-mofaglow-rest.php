<?php
class MOFAGLOW_REST {
  public static function init() { add_action( 'rest_api_init', array( __CLASS__, 'routes' ) ); }
  public static function routes() {
    register_rest_route( 'mofaglow/v1', '/suppliers', array( 'methods' => 'GET', 'callback' => function () { return rest_ensure_response( MOFAGLOW_Suppliers::all() ); }, 'permission_callback' => function () { return current_user_can( 'manage_woocommerce' ); } ) );
    register_rest_route( 'mofaglow/v1', '/spaceseller/test', array( 'methods' => 'POST', 'callback' => function () { return rest_ensure_response( ( new MOFAGLOW_SpaceSeller_Adapter() )->test_connection() ); }, 'permission_callback' => function () { return current_user_can( 'manage_woocommerce' ); } ) );
    register_rest_route( 'mofaglow/v1', '/profit/product', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'profit' ), 'permission_callback' => function () { return current_user_can( 'manage_woocommerce' ); } ) );
  }
  public static function profit( $r ) { $p = $r->get_json_params(); $s = (float)($p['selling']??0); $c = (float)($p['cost']??0); return rest_ensure_response( array( 'profit' => MOFAGLOW_Profit::product_profit($s,$c), 'margin' => MOFAGLOW_Profit::product_margin($s,$c), 'formatted' => MOFAGLOW_Profit::format_mad( MOFAGLOW_Profit::product_profit($s,$c) ) ) ); }
}