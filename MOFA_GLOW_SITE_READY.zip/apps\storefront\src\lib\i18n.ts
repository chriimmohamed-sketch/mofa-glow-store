export const locales = ["ar", "fr", "en"] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = "ar";
export function isLocale(value: string): value is Locale { return (locales as readonly string[]).includes(value); }
export function dirFor(locale: Locale): "rtl" | "ltr" { return locale === "ar" ? "rtl" : "ltr"; }
export async function getMessages(locale: Locale) {
  switch (locale) {
    case "fr": return (await import("../../messages/fr.json")).default;
    case "en": return (await import("../../messages/en.json")).default;
    default: return (await import("../../messages/ar.json")).default;
  }
}