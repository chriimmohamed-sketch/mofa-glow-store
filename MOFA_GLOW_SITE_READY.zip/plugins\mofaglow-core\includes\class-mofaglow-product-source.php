<?php
class MOFAGLOW_Product_Source {
  const SOURCE = '_mofaglow_source'; const SUPPLIER = '_mofaglow_supplier_id'; const COST = '_mofaglow_purchase_cost';
  public static function get_source( $id ) { $s = get_post_meta( $id, self::SOURCE, true ); return in_array( $s, array( 'OWN_BRAND', 'DROPSHIPPING' ), true ) ? $s : 'OWN_BRAND'; }
  public static function set_source( $id, $s ) { if ( ! in_array( $s, array( 'OWN_BRAND', 'DROPSHIPPING' ), true ) ) return false; update_post_meta( $id, self::SOURCE, $s ); return true; }
  public static function set_supplier( $id, $sid ) { update_post_meta( $id, self::SUPPLIER, (int) $sid ); }
  public static function set_cost( $id, $c ) { update_post_meta( $id, self::COST, number_format( (float) $c, 2, '.', '' ) ); }
  public static function sanitize_for_customer( $d ) { unset( $d['purchase_cost'], $d['supplier'], $d['supplier_id'] ); return $d; }
}