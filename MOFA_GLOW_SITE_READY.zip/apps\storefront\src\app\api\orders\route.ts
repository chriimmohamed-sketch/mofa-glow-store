import { NextResponse } from "next/server";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { createOrder } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/supabase";

export async function POST(request: Request) {
  const gate = rateLimit(`${clientKey(request)}:orders`, 5, 60_000);
  if (!gate.allowed) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  let body: any;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "invalid_json" }, { status: 400 }); }

  const { customer, payment, items } = body;
  if (!customer?.firstName || !customer?.phone || !customer?.address || !customer?.city) {
    return NextResponse.json({ error: "invalid_input", message: "Missing required customer fields." }, { status: 400 });
  }
  if (!items || !Array.isArray(items) || items.length === 0) {
    return NextResponse.json({ error: "invalid_input", message: "Cart is empty." }, { status: 400 });
  }
  if (payment !== "cod") {
    return NextResponse.json({ error: "payment_not_available", message: "Online payment is not available yet." }, { status: 400 });
  }

  const reference = body.reference || `MG-${Date.now().toString(36).toUpperCase()}`;
  const subtotal = items.reduce((sum: number, i: any) => sum + i.price * i.qty, 0);
  const shippingFee = subtotal >= 400 ? 0 : 35;
  const total = subtotal + shippingFee;

  const result = await createOrder({
    reference,
    customer: {
      firstName: customer.firstName,
      lastName: customer.lastName || "",
      phone: customer.phone,
      email: customer.email || "",
      address: customer.address,
      city: customer.city,
    },
    items: items.map((i: any) => ({ productId: i.productId, name: i.name, sku: i.sku, price: i.price, qty: i.qty })),
    subtotal,
    shippingFee,
    total,
    paymentMethod: "cod",
  });

  if (!result.success) {
    // If Supabase not configured, return success (local preview mode)
    if (!isSupabaseConfigured()) {
      return NextResponse.json({ message: "Order received (local preview).", reference });
    }
    return NextResponse.json({ error: "order_failed", message: result.error || "Could not create order." }, { status: 500 });
  }

  return NextResponse.json({ message: "Order received.", reference: result.reference });
}
