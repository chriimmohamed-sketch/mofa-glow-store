<?php
class MOFAGLOW_Suppliers {
  public static function table() { global $wpdb; return $wpdb->prefix . 'mofaglow_suppliers'; }
  public static function all() { global $wpdb; return $wpdb->get_results( "SELECT * FROM " . self::table() . " ORDER BY name ASC" ); }
  public static function create( $d ) {
    global $wpdb;
    $wpdb->insert( self::table(), array( 'name' => sanitize_text_field( $d['name'] ), 'email' => sanitize_email( $d['email'] ?? '' ), 'phone' => sanitize_text_field( $d['phone'] ?? '' ), 'status' => 'active' ) );
    return $wpdb->insert_id;
  }
}