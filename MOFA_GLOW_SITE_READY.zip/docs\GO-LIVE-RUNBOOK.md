# MOFA GLOW — Go-Live Runbook (ما يمكنني تنفيذه الآن وما يتطلبك)

> قاعدة حاكمة: لن أختلق بيانات/حسابات/مفاتيح ولن أدّعي تفعيل تكامل أو نشر إلا بعد تنفيذه والتحقق منه. أي خطوة تعتمد على طرف خارجي غير متاح تُصنّف: **BLOCKED / NOT CONFIGURED / NOT VERIFIED**.

## الحالة الحالية (جاهز)
- الواجهة الأمامية كاملة وتبني بنجاح (`npm run build`) وتختبر بنجاح (`npm test` 16/16).
- معاينة مباشرة (مؤقتة): https://garmin-cent-assume-seasonal.trycloudflare.com/ar
- إضافة ووردبريس: `plugins/mofaglow-core/`
- إعدادات النشر: `apps/storefront/wrangler.toml`, `.github/workflows/deploy.yml`, `docs/DEPLOYMENT.md`
- متغيرات مطلوبة (قوالب فقط): `.env.example`, `apps/storefront/.env.example`

## 1) إنشاء متجر WooCommerce حي — **يتطلب إجراء منك (BLOCKED)**
لا أستطيع إنشاء حساب استضافة/دفع أو شراء خدمة نيابةً عنك.
1. افتح (مفتوح لديك): https://woocommerce.com/start/#hosts واختر استضافة تدعم WordPress + WooCommerce + PHP + MySQL/MariaDB + SSL.
2. ثبّت WordPress ثم WooCommerce، فعّل SSL، واضبط العملة **MAD** واللغات (ar/fr/en) وRTL.
3. أنشئ المنتجات/الفئات/الشحن/الضرائب وفق البيانات المعتمدة (لا تنشر ادعاءات غير مُتحقق منها).
4. فعّل إضافة المشروع: ارفع وثبّت `plugins/mofaglow-core` من هذا المستودع.
5. أنشئ مفاتيح REST API (WooCommerce → Settings → Advanced → REST API، صلاحيات قراءة/كتابة).

**سلّمني بعد ذلك:**
- `WC_API_URL` (مثال: `https://yourstore.com`)
- `WC_CONSUMER_KEY`
- `WC_CONSUMER_SECRET`
- رابط دخول الإدارة `.../wp-admin`

➡️ بمجرد استلامها: سأضبطها في بيئة الخادم (وليس في الواجهة)، أختبر إنشاء طلب COD حقيقي عبر `/api/orders`، وأتحقق من ظهور الطلب في WooCommerce.

## 2) SpaceSeller — **يتطلب حسابك/توثيقًا رسميًا (BLOCKED / NOT VERIFIED)**
لوحة الدخول مفتوحة لديك: https://drop.spaceseller.ma/admin/login
- أحتاج: وصول تاجر (أو مفاتيح/توثيق التكامل الرسمي الذي يوفّره SpaceSeller بعد تسجيل الدخول) + تأكيد آلية الربط (WooCommerce plugin رسمي أم API موثّق).
- لن أخترع endpoints أو أسرّب مفاتيح للواجهة الأمامية.

➡️ بمجرد توفر التوثيق/الوصول: سأفعّل `SpaceSellerAdapter` في `plugins/mofaglow-core`، أضبط مزامنة idempotent بـ `external_order_id`، وأنفّذ **طلب اختبار** وأؤكد حالة الإرسال قبل اعتباره VERIFIED.

## 3) الدفع الإلكتروني — **يتطلب مزودًا مغربيًا مُتحققًا (BLOCKED)**
- الدفع عند الاستلام (COD): جاهز تقنيًا، يُفعّل فعليًا بعد ربط WooCommerce.
- الدفع الإلكتروني: يبقى **معطّلًا** حتى اختيار مزود مغربي معتمد وتوفير مفاتيح الاختبار/الإنتاج وتوثيق callbacks/webhooks.
- ممنوع تخزين بيانات البطاقات؛ ولا نجاح للدفع بناءً على redirect وحده.

➡️ سلّمني: المزود المختار + مفاتيح sandbox/production + توثيق التحقق من التوقيع/الإشعارات، وسأنفّذ التكامل server-side وأختبره قبل التفعيل.

## 4) النشر الدائم على `mofaglow.ma` — **يتطلب Cloudflare + نطاقك (BLOCKED)**
لوحة الدخول مفتوحة لديك: https://dash.cloudflare.com/login
لا أستطيع شراء/نقل النطاق أو إنشاء حساب Cloudflare نيابةً عنك.

**سلّمني:**
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`
- تأكيد أن نطاق `mofaglow.ma` مُدار في حسابك على Cloudflare (أو صلاحية DNS)

➡️ بمجرد استلامها سأقوم بـ:
1. ضبط الأسرار في بيئة النشر (GitHub Secrets / Wrangler) وتشغيل نشر OpenNext/Workers (`apps/storefront`).
2. ربط النطاق/المسارات والتحقق من SSL وHTTPS.
3. ضبط `NEXT_PUBLIC_SITE_URL=https://mofaglow.ma` وإعادة التحقق من sitemap/robots/canonical.
4. اختبار تدخين: `/ar`, `/shop`, منتج، سلة، دفع (COD بعد ربط WooCommerce).

## 5) ما سأفعّله فورًا عند استلام المدخلات
- [ ] ربط WooCommerce والتحقق بطلب تجريبي حقيقي
- [ ] تفعيل/تحقق SpaceSeller وفق التوثيق الرسمي فقط
- [ ] تفعيل مزود الدفع بعد اختبار sandbox والتحقق من webhooks
- [ ] نشر دائم إلى `mofaglow.ma` والتحقق بعد النشر
- [ ] تحديث `docs/FINAL-QUALITY-REPORT.md` بنتائج مُثبتة (VERIFIED) لكل عنصر

## بيانات أحتاجها منك في رسالة واحدة (قالب)
```
WP_ADMIN_URL:
WC_API_URL:
WC_CONSUMER_KEY:
WC_CONSUMER_SECRET:
SPACESELLER (وصف الوصول/التوثيق المتاح):
PAYMENT_PROVIDER (+ مفاتيح sandbox):
CLOUDFLARE_API_TOKEN:
CLOUDFLARE_ACCOUNT_ID:
DOMAIN_STATUS (mofaglow.ma مُضاف إلى Cloudflare؟ نعم/لا):
```
لا ترسل أسرارًا في محادثة عامة إن لم تكن تثق بالقناة؛ استخدم قناة آمنة. سأتعامل معها كأسرار خادم فقط.