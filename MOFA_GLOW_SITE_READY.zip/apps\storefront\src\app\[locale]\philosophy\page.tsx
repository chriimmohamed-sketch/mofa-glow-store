import { isLocale, getMessages } from "@/lib/i18n";
import PolicyLayout from "@/components/PolicyLayout";

export default async function PhilosophyPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <PolicyLayout locale={l} messages={m} title="Our Philosophy">
      <p>MOFA GLOW is built on quiet luxury: clean, confident, and generous with space. We believe beauty is a feeling, not a contest.</p>
      <p>Our visual universe rests on three abstract symbols: LIGHT for clarity, FORM for renewal, and PEARL for value and texture. They guide composition — they are not claims about ingredients.</p>
      <p>We work with two models: MOFA GLOW private-label products and a small curated range of supplier formulas reimagined under our identity. We disclose what is known and mark what is not verified.</p>
      <p>We do not fabricate reviews, sales counters, urgency, ingredients, manufacturing countries, or certifications. When information is pending, we say so.</p>
    </PolicyLayout>
  );
}