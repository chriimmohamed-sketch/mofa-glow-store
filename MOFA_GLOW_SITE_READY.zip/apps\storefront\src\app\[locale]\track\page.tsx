import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TrackOrder from "@/components/TrackOrder";

export default async function TrackPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <>
      <Header locale={l} messages={m} />
      <main className="container py-16">
        <div className="eyebrow mb-3">TRACK MY ORDER</div>
        <h1 className="font-display display-md mb-4">Where is my order?</h1>
        <p className="text-sm text-[var(--muted)] mb-8 max-w-xl">
          Enter the reference shown at checkout. Live carrier tracking becomes available once the commerce backend is connected.
        </p>
        <TrackOrder />
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}