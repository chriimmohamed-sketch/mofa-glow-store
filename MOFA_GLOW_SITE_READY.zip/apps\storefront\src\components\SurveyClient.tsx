"use client";
import { useEffect, useState } from "react";
const KEY = "mg_survey_draft";
export default function SurveyClient() {
  const [form, setForm] = useState<any>({ category: "", factor: "", priceRange: "", missing: "", firstProduct: "", localBrand: "", follow: false, email: "" });
  const [state, setState] = useState("idle"); const [message, setMessage] = useState("");
  useEffect(() => { try { const r = localStorage.getItem(KEY); if (r) setForm(JSON.parse(r)); } catch {} }, []);
  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(form)); }, [form]);
  const set = (k: string) => (e: any) => setForm({ ...form, [k]: e.target.value });
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setState("loading");
    try {
      const res = await fetch("/api/survey", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const d = await res.json(); if (!res.ok) throw new Error(d.message || d.error);
      setState("done"); setMessage(d.message || "Thank you."); localStorage.removeItem(KEY);
    } catch (err: any) { setState("error"); setMessage(err.message); }
  }
  const f = "w-full border border-[var(--line)] bg-[var(--surface)] p-3";
  return <form onSubmit={submit} className="space-y-5 max-w-2xl">
    <label className="block"><span className="block text-sm font-semibold mb-2">1. Category? *</span><select required className={f} value={form.category} onChange={set("category")}><option value="">—</option><option value="face">Face</option><option value="body">Body</option><option value="hair">Hair</option><option value="makeup">Makeup</option></select></label>
    <label className="block"><span className="block text-sm font-semibold mb-2">2. Most important factor? *</span><select required className={f} value={form.factor} onChange={set("factor")}><option value="">—</option><option value="quality">Quality</option><option value="price">Price</option><option value="ingredients">Ingredients</option><option value="trust">Trust</option></select></label>
    <label className="block"><span className="block text-sm font-semibold mb-2">3. Price range?</span><input className={f} value={form.priceRange} onChange={set("priceRange")} /></label>
    <label className="block"><span className="block text-sm font-semibold mb-2">4. What is missing in the Moroccan market?</span><textarea className={f} rows={3} value={form.missing} onChange={set("missing")} /></label>
    <label className="block"><span className="block text-sm font-semibold mb-2">5. First product you'd like to see?</span><input className={f} value={form.firstProduct} onChange={set("firstProduct")} /></label>
    <label className="block"><span className="block text-sm font-semibold mb-2">6. Local brand with global identity?</span><select className={f} value={form.localBrand} onChange={set("localBrand")}><option value="">—</option><option value="yes">Yes</option><option value="no">No</option><option value="maybe">Maybe</option></select></label>
    <label className="flex items-start gap-3 text-sm"><input type="checkbox" checked={form.follow} onChange={(e) => setForm({ ...form, follow: e.target.checked })} className="mt-1" /><span>Follow updates? Email optional, only with consent.</span></label>
    {form.follow && <input type="email" className={f} value={form.email} onChange={set("email")} placeholder="Email (optional)" />}
    {state === "error" && <p role="alert" className="text-sm text-red-600">{message}</p>}
    {state === "done" && <p role="status" className="text-sm text-green-700">{message}</p>}
    <button type="submit" disabled={state === "loading"} className="btn btn-primary">{state === "loading" ? "..." : "Send"}</button>
  </form>;
}