export interface Coupon { code: string; type: "percent" | "fixed"; value: number; minSubtotal?: number; active: boolean; }
export const coupons: Coupon[] = [
  { code: "GLOW10", type: "percent", value: 10, minSubtotal: 200, active: true },
  { code: "WELCOME20", type: "fixed", value: 20, minSubtotal: 100, active: true },
];
export function validateCoupon(code: string, subtotal: number) {
  const c = coupons.find((x) => x.code === code.trim().toUpperCase());
  if (!c) return { valid: false as const, reason: "invalid_code" };
  if (!c.active) return { valid: false as const, reason: "inactive" };
  if (c.minSubtotal && subtotal < c.minSubtotal) return { valid: false as const, reason: "min_subtotal" };
  const discount = c.type === "percent" ? (subtotal * c.value) / 100 : c.value;
  return { valid: true as const, discount: Math.round(discount * 100) / 100, coupon: c };
}