// Server-side only. Never expose secrets to client.
export class SpaceSellerAdapter {
  constructor(private config: { baseUrl?: string; apiKey?: string; apiSecret?: string }) {}
  async testConnection() { return { ok: false, message: "Not implemented: awaiting official SpaceSeller documentation." }; }
  async syncOrder(order: { id: string }) { return { success: false, error: "not_implemented" }; }
  async syncOrderStatus() { return { success: false, error: "not_implemented" }; }
}
export function createSpaceSellerAdapter() {
  return new SpaceSellerAdapter({ baseUrl: process.env.SPACESSELLER_BASE_URL, apiKey: process.env.SPACESSELLER_API_KEY, apiSecret: process.env.SPACESSELLER_API_SECRET });
}