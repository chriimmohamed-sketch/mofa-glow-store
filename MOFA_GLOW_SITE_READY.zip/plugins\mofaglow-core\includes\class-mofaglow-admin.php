<?php
class MOFAGLOW_Admin {
  public static function init() { add_action( 'admin_menu', array( __CLASS__, 'menu' ) ); }
  public static function menu() {
    add_menu_page( 'MOFA GLOW', 'MOFA GLOW', 'manage_woocommerce', 'mofaglow-dashboard', array( __CLASS__, 'dashboard' ), 'dashicons-store', 56 );
    add_submenu_page( 'mofaglow-dashboard', 'Suppliers', 'Suppliers', 'manage_woocommerce', 'mofaglow-suppliers', array( __CLASS__, 'suppliers' ) );
    add_submenu_page( 'mofaglow-dashboard', 'SpaceSeller', 'SpaceSeller', 'manage_woocommerce', 'mofaglow-ss', array( __CLASS__, 'ss' ) );
    add_submenu_page( 'mofaglow-dashboard', 'Sync Logs', 'Sync Logs', 'manage_woocommerce', 'mofaglow-logs', array( __CLASS__, 'logs' ) );
    add_submenu_page( 'mofaglow-dashboard', 'Survey', 'Survey', 'manage_woocommerce', 'mofaglow-survey', array( __CLASS__, 'survey' ) );
  }
  public static function dashboard() { echo '<div class="wrap"><h1>MOFA GLOW Admin</h1><p>Dashboard.</p></div>'; }
  public static function suppliers() { echo '<div class="wrap"><h1>Suppliers</h1>'; foreach ( MOFAGLOW_Suppliers::all() as $s ) echo '<p>' . esc_html( $s->name ) . '</p>'; echo '</div>'; }
  public static function ss() { $a = new MOFAGLOW_SpaceSeller_Adapter(); $r = $a->test_connection(); echo '<div class="wrap"><h1>SpaceSeller</h1><p>' . esc_html( $r['message'] ) . '</p></div>'; }
  public static function logs() { echo '<div class="wrap"><h1>Sync Logs</h1>'; foreach ( MOFAGLOW_Sync_Log::jobs() as $j ) echo '<p>#' . esc_html($j->id) . ' ' . esc_html($j->job_type) . ' — ' . esc_html($j->status) . '</p>'; echo '</div>'; }
  public static function survey() { global $wpdb; $rows = $wpdb->get_results( "SELECT * FROM " . MOFAGLOW_Survey::table() . " ORDER BY created_at DESC LIMIT 100" ); echo '<div class="wrap"><h1>Survey</h1><table class="widefat"><thead><tr><th>ID</th><th>Category</th><th>Factor</th><th>First product</th></tr></thead><tbody>'; foreach ( $rows as $r ) echo '<tr><td>' . esc_html($r->id) . '</td><td>' . esc_html($r->category) . '</td><td>' . esc_html($r->factor) . '</td><td>' . esc_html($r->first_product) . '</td></tr>'; echo '</tbody></table></div>'; }
}