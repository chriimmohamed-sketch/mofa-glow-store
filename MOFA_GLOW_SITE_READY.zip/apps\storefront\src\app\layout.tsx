import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from "@/lib/cart";
import { WishlistProvider } from "@/lib/wishlist";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://mofaglow.ma";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "MOFA GLOW — Your Skin. Your Glow.", template: "%s | MOFA GLOW" },
  description: "Independent Moroccan beauty and skincare house. Quiet luxury, curated formulas, cash on delivery across Morocco.",
  keywords: ["MOFA GLOW", "Morocco", "skincare", "beauty", "MAD", "cash on delivery", "دليل", "جمال", "مغرب"],
  openGraph: {
    type: "website",
    siteName: "MOFA GLOW",
    locale: "ar_MA",
    alternateLocale: ["fr_MA", "en_US"],
    title: "MOFA GLOW — Your Skin. Your Glow.",
    description: "Quiet luxury beauty, crafted for Morocco.",
    images: ["/brand/logo-concepts.png"],
  },
  twitter: { card: "summary_large_image" },
  alternates: {
    canonical: "/",
    languages: { ar: "/ar", fr: "/fr", en: "/en" },
  },
  robots: { index: true, follow: true },
};

const organizationLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "MOFA GLOW",
  slogan: "Your Skin. Your Glow.",
  url: siteUrl,
  logo: `${siteUrl}/brand/logo-concepts.png`,
  areaServed: { "@type": "Country", name: "Morocco" },
  knowsAbout: ["Skincare", "Beauty", "Private label", "Dropshipping"],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Inter:wght@500;600&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationLd) }} />
      </head>
      <body>
        <CartProvider><WishlistProvider>{children}</WishlistProvider></CartProvider>
      </body>
    </html>
  );
}