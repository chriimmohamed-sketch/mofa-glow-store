import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";

export default async function FounderPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <>
      <Header locale={l} messages={m} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-16 sm:py-20">
        <div className="bg-[#F3EBDD]/75 border border-[#D9C7AD] rounded-3xl p-6 sm:p-10 lg:p-12 shadow-[0_20px_50px_-20px_rgba(36,36,36,0.08)]">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            <div className="lg:col-span-6 space-y-5 text-right">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF7F2] border border-[#D9C7AD] text-xs text-[#B38A4C] font-medium">
                <span>نادي النخبة • MOFA PRIVÉ</span>
              </div>
              <h1 className="font-serif text-3xl sm:text-4xl text-[#242424]">أصدري بطاقة عضوية المؤسسين الخاصة بكِ</h1>
              <p className="text-sm text-[#242424]/75 leading-relaxed">
                احصلي على بطاقتكِ الرقمية المذهّبة باسمكِ مع امتيازات حصرية تشمل أولوية الحصول على الإصدارات الجديدة وخصم دائم بنسبة 15% باستخدام رمز <strong className="tracking-wider text-[#242424]">GLOW2026</strong>.
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-4">
                <Link href={`/${l}/shop`} className="px-6 py-3 rounded-full bg-[#242424] text-[#FAF7F2] text-sm font-medium hover:bg-[#242424]/90 transition-all">
                  انضمي الآن
                </Link>
                <span className="text-xs text-[#242424]/60">رمز الامتياز: GLOW2026 (-15%)</span>
              </div>
            </div>

            <div className="lg:col-span-6 flex justify-center">
              <div className="w-full max-w-md aspect-[1.6/1] rounded-3xl p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden border border-[#B38A4C]/60 shadow-2xl bg-gradient-to-br from-[#FAF7F2] via-[#F3EBDD] to-[#D9C7AD]/60 text-[#242424]">
                <div className="absolute -left-12 -bottom-12 w-48 h-48 rounded-full border border-[#B38A4C]/25 pointer-events-none" />
                <div className="absolute -left-6 -bottom-6 w-36 h-36 rounded-full border border-[#B38A4C]/20 pointer-events-none" />

                <div className="flex items-start justify-between relative z-10">
                  <div>
                    <span className="tracking-[0.22em] text-lg sm:text-xl font-semibold block">MOFA GLOW</span>
                    <span className="text-[10px] tracking-[0.25em] text-[#B38A4C] uppercase">FOUNDER CIRCLE • 2026</span>
                  </div>
                  <div className="w-10 h-10 rounded-full border border-[#B38A4C]/50 flex items-center justify-center bg-[#B38A4C]/10">
                    <svg className="w-5 h-5 text-[#B38A4C]" viewBox="0 0 32 32" fill="none">
                      <path d="M16 4C16 4 8 13.5 8 19.2C8 23.6 11.6 27.2 16 27.2C20.4 27.2 24 23.6 24 19.2C24 13.5 16 4 16 4Z" stroke="currentColor" strokeWidth="1.8" />
                    </svg>
                  </div>
                </div>

                <div className="relative z-10 my-auto py-2">
                  <p className="text-[11px] opacity-65 mb-0.5">حامل البطاقة</p>
                  <p className="font-serif text-2xl sm:text-3xl tracking-wide">سلمى الإدريسي</p>
                  <p className="text-xs opacity-75 mt-1">الدار البيضاء • المغرب</p>
                </div>

                <div className="flex items-end justify-between relative z-10 pt-3 border-t border-[#B38A4C]/25 text-xs">
                  <div>
                    <span className="text-[10px] opacity-60 block">رقم العضوية</span>
                    <span className="tracking-widest font-medium">MG-2026-8841</span>
                  </div>
                  <div className="text-left">
                    <span className="text-[10px] opacity-60 block">كود الامتياز</span>
                    <span className="tracking-wider font-semibold text-[#B38A4C]">GLOW2026 (-15%)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}
