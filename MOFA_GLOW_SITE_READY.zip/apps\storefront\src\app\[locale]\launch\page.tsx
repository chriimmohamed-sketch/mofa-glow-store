import { isLocale, getMessages } from "@/lib/i18n";
import { campaign } from "@/lib/campaign";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";
export default async function LaunchPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params; const l = isLocale(locale) ? locale : "ar"; const m = await getMessages(l); const c = campaign[l];
  return <><Header locale={l} messages={m} /><main className="container py-12">
    <div className="eyebrow mb-3">MOFA GLOW — 7 DAYS</div><h1 className="font-display text-4xl md:text-5xl mb-4">{c.intro}</h1><p className="text-[var(--muted)] max-w-2xl mb-8">{c.note}</p>
    <Link href={`/${l}/survey`} className="btn btn-gold mb-12">Help us shape MOFA GLOW →</Link>
    <div className="grid md:grid-cols-2 gap-5">{c.days.map((d) => <article key={d.day} className="card p-6">
      <div className="eyebrow mb-2">DAY 0{d.day} · {d.type}</div><h2 className="font-display text-2xl mb-3">{d.title}</h2>
      <p className="text-sm text-[var(--muted)] mb-3">{d.visual}</p><p className="text-sm mb-4">{d.text}</p><div className="text-sm text-[var(--accent)]">↳ {d.cta}</div>
    </article>)}</div>
  </main><Footer locale={l} messages={m} /></>;
}