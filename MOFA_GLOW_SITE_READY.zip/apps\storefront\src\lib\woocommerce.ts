const URL = process.env.WC_API_URL || "";
const KEY = process.env.WC_CONSUMER_KEY || "";
const SECRET = process.env.WC_CONSUMER_SECRET || "";
async function wc(path: string, init?: RequestInit) {
  if (!URL) throw new Error("WC_API_URL not configured");
  const res = await fetch(`${URL}/wp-json/wc/v3${path}`, { ...init, cache: "no-store", headers: { Authorization: "Basic " + Buffer.from(`${KEY}:${SECRET}`).toString("base64"), "Content-Type": "application/json", ...(init?.headers || {}) } });
  if (!res.ok) throw new Error(`WooCommerce ${res.status}: ${await res.text()}`);
  return res.json();
}
export const woo = {
  listProducts: (p?: Record<string, string>) => wc(`/products${p ? "?" + new URLSearchParams(p) : ""}`),
  createOrder: (payload: any) => wc("/orders", { method: "POST", body: JSON.stringify(payload) }),
};
export function isWooConfigured() { return Boolean(URL && KEY && SECRET); }