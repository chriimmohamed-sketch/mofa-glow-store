"use client";
import { useWishlist } from "@/lib/wishlist";
export default function WishlistButton({ productId }: { productId: string }) {
  const { toggle, has } = useWishlist(); const active = has(productId);
  return <button type="button" aria-label="wishlist" aria-pressed={active} onClick={(e) => { e.preventDefault(); toggle(productId); }} className="w-9 h-9 border border-[var(--line)] flex items-center justify-center text-lg" style={{ color: active ? "var(--accent)" : "var(--muted)" }}>{active ? "♥" : "♡"}</button>;
}