<?php
class MOFAGLOW_DB {
  public static function activate() {
    global $wpdb; $c = $wpdb->get_charset_collate(); $p = $wpdb->prefix . 'mofaglow_';
    $sqls = array(
      "CREATE TABLE {$p}suppliers (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, name varchar(191) NOT NULL, contact varchar(191) DEFAULT NULL, email varchar(191) DEFAULT NULL, phone varchar(64) DEFAULT NULL, status varchar(32) NOT NULL DEFAULT 'active', created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (id)) $c;",
      "CREATE TABLE {$p}supplier_products (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, supplier_id bigint(20) unsigned NOT NULL, product_id bigint(20) unsigned NOT NULL, supplier_sku varchar(191) DEFAULT NULL, purchase_cost decimal(12,2) NOT NULL DEFAULT 0.00, availability varchar(32) NOT NULL DEFAULT 'unknown', lead_time_days int(11) DEFAULT NULL, PRIMARY KEY (id), KEY supplier_id (supplier_id), KEY product_id (product_id)) $c;",
      "CREATE TABLE {$p}sync_jobs (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, job_type varchar(64) NOT NULL, status varchar(32) NOT NULL DEFAULT 'pending', payload longtext DEFAULT NULL, attempts int(11) NOT NULL DEFAULT 0, last_error text DEFAULT NULL, external_order_id varchar(191) DEFAULT NULL, created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY status (status), KEY external_order_id (external_order_id)) $c;",
      "CREATE TABLE {$p}sync_logs (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, job_id bigint(20) unsigned DEFAULT NULL, level varchar(16) NOT NULL DEFAULT 'info', message text NOT NULL, context longtext DEFAULT NULL, created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY job_id (job_id)) $c;",
      "CREATE TABLE {$p}audit_events (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned DEFAULT NULL, action varchar(191) NOT NULL, entity_type varchar(64) DEFAULT NULL, entity_id varchar(64) DEFAULT NULL, created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY user_id (user_id)) $c;"
    );
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    foreach ( $sqls as $sql ) dbDelta( $sql );
    update_option( 'mofaglow_core_db_version', MOFAGLOW_CORE_VERSION );
  }
}