import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
export default async function Page({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params; const l = isLocale(locale) ? locale : "ar"; const m = await getMessages(l);
  return <><Header locale={l} messages={m} /><main className="container py-12 max-w-3xl"><h1 className="font-display text-3xl mb-4">{(m as any).nav["terms"] || (m as any).footer["terms"] || "terms"}</h1><p className="text-[var(--muted)]">Terms & conditions placeholder.</p></main><Footer locale={l} messages={m} /></>;
}