# Security

HTTPS via Cloudflare. Secrets in env only (`.env.example` placeholders). Server-side validation. wpdb prepared statements. Role-gated admin (`manage_woocommerce`). Survey honeypot + rate limit. Webhook signature verification must be implemented with chosen provider. No card data stored. Supplier costs never exposed to customers.
