# Official Brand Profile

Source: MOFA_GLOW_Official_Brand_Profile_and_Launch_Plan.docx (v1.0, Nov 2026).

Positioning: Quiet Luxury. Slogan: Your Skin. Your Glow. / بشرتك، إشراقتك.
Palette: Champagne #D9C7AD, Ivory #F3EBDD, Black #242424, Soft Taupe #B9A18D, Gold #B8894B, Espresso #2A221B.
Type: Fraunces (display), Jost (body), Tajawal (Arabic).
Rules: no clutter, no loud colors, no fake products/reviews/urgency. Verify trademark and handles before final use.
