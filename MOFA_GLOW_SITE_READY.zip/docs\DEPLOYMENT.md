# Deployment

Storefront can be deployed to Cloudflare Workers via OpenNext (`@opennextjs/cloudflare`, `wrangler.toml`). Requires Cloudflare API token, account ID, and domain. No deploy has been performed. See docs/FINAL-STATUS.md.
