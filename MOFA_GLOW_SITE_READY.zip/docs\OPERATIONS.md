# Operations Guide — MOFA GLOW

## Local preview
```bash
cd apps/storefront
npm install
npm run dev
# http://localhost:3000/ar  (/fr, /en)
npm test          # unit tests
npm run build     # production build validation
```
A public temporary preview can be exposed with a Cloudflare quick tunnel:
`cloudflared tunnel --url http://localhost:3000`

## Before selling (blockers)
1. Install WordPress + WooCommerce with SSL, backups, MAD currency, Arabic RTL.
2. Create products/categories, shipping zones, taxes and payment methods from verified data.
3. Set `WC_API_URL`, `WC_CONSUMER_KEY`, `WC_CONSUMER_SECRET` in the server environment.
4. Activate `plugins/mofaglow-core` in WordPress and run its activation migrations.
5. Verify SpaceSeller's official integration method; do not automate undocumented flows.
6. Select and test a Moroccan payment provider; keep online payment disabled until then.
7. Point `mofaglow.ma` to Cloudflare, deploy, verify SSL and backups.

## Product & inventory management
Products, stock and orders are managed in WooCommerce once connected. The `mofaglow-core` plugin adds
suppliers, product source (OWN_BRAND / DROPSHIPPING), purchase costs, sync jobs and logs.
Never expose purchase costs or supplier identities on the storefront.

## Profit reporting
- Product profit = selling price − purchase cost
- Product margin = profit ÷ selling price
- Net order profit = amount collected − product cost − shipping/fulfilment − payment/platform fees − discounts − returns − other variable costs
Confirm the accounting treatment with a qualified professional before using figures officially.

## Backup & recovery
- Back up WordPress files and MySQL database on a schedule; encrypt backups.
- Test restoration into a staging environment before launch and after major changes.
- Keep deployment rollback instructions in `docs/DEPLOYMENT.md`.

## Monitoring
Check the Command Center (`/admin`) for integration health. All external integrations must show
NOT VERIFIED until confirmed by the external system. Audit events are recorded in the plugin's
`wp_mofaglow_audit_events` table.
