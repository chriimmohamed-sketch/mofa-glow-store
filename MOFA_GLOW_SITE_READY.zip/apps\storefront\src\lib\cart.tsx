"use client";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
interface Item { productId: string; slug: string; name: string; price: number; qty: number; }
interface Ctx { items: Item[]; add: (i: Omit<Item, "qty">, qty?: number) => void; remove: (id: string) => void; clear: () => void; count: number; subtotal: number; }
const C = createContext<Ctx | null>(null);
export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Item[]>([]);
  useEffect(() => { try { const r = localStorage.getItem("mg_cart"); if (r) setItems(JSON.parse(r)); } catch {} }, []);
  useEffect(() => { localStorage.setItem("mg_cart", JSON.stringify(items)); }, [items]);
  const add: Ctx["add"] = (i, qty = 1) => setItems((p) => { const f = p.find((x) => x.productId === i.productId); return f ? p.map((x) => x.productId === i.productId ? { ...x, qty: x.qty + qty } : x) : [...p, { ...i, qty }]; });
  const remove = (id: string) => setItems((p) => p.filter((x) => x.productId !== id));
  const clear = () => setItems([]);
  const count = items.reduce((a, b) => a + b.qty, 0);
  const subtotal = items.reduce((a, b) => a + b.price * b.qty, 0);
  return <C.Provider value={{ items, add, remove, clear, count, subtotal }}>{children}</C.Provider>;
}
export function useCart() { const c = useContext(C); if (!c) throw new Error("useCart outside provider"); return c; }
