type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

/** Lightweight in-process rate limiter. Use edge/Cloudflare rate limiting in production. */
export function rateLimit(key: string, limit = 5, windowMs = 60_000) {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: limit - 1 };
  }
  if (bucket.count >= limit) return { allowed: false, remaining: 0 };
  bucket.count += 1;
  return { allowed: true, remaining: limit - bucket.count };
}

export function clientKey(request: Request) {
  const h = request.headers;
  return h.get("x-forwarded-for") || h.get("x-real-ip") || "unknown";
}