# Database

WooCommerce owns products, orders, customers, coupons. Custom `wp_mofaglow_*` tables: suppliers, supplier_products, sync_jobs, sync_logs, audit_events, survey_responses. Created via dbDelta on plugin activation.
