"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import MofaLogo from "@/components/MofaLogo";
import MobileMenu from "@/components/MobileMenu";
const locales = ["ar", "fr", "en"] as const;

export default function Header({ locale, messages }: { locale: string; messages: any }) {
  const pathname = usePathname();
  const n = messages.nav;
  const to = (l: string) => { const parts = pathname.split("/").filter(Boolean); if (locales.includes(parts[0] as any)) parts[0] = l; else parts.unshift(l); return "/" + parts.join("/"); };
  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/90 backdrop-blur-md border-b border-[#D9C7AD]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 h-20 flex items-center justify-between gap-4">
        {/* Brand Identity */}
        <Link href={`/${locale}`} className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-[#F3EBDD] border border-[#D9C7AD] flex items-center justify-center shadow-sm group-hover:border-[#B38A4C] transition-colors">
            <svg className="w-5 h-5 text-[#242424]" viewBox="0 0 32 32" fill="none">
              <path d="M16 3C16 3 7 13.2 7 19.5C7 24.4706 11.0294 28.5 16 28.5C20.9706 28.5 25 24.4706 25 19.5C25 13.2 16 3 16 3Z" stroke="#C5A059" strokeWidth="1.6" fill="#FAF7F2" />
              <path d="M16 9C16 9 11.5 15 11.5 18.8C11.5 21.2853 13.5147 23.3 16 23.3" stroke="#242424" strokeWidth="1.3" strokeLinecap="round" />
            </svg>
          </div>
          <div>
            <span className="font-display tracking-[0.2em] text-lg sm:text-xl font-semibold text-[#242424] block leading-none">MOFA GLOW</span>
            <span className="text-[11px] text-[#B9A18D] tracking-wider block mt-1">بَشَرَتُكِ، إِشْرَاقَتُكِ</span>
          </div>
        </Link>

        {/* Center Nav Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm text-[#242424]/80">
          <Link href={`/${locale}/shop`} className="hover:text-[#242424] transition-colors font-medium">{n.shop}</Link>
          <Link href={`/${locale}/collections`} className="hover:text-[#242424] transition-colors">المجموعة (8)</Link>
          <Link href={`/${locale}/philosophy`} className="hover:text-[#242424] transition-colors">فلسفة التركيبات</Link>
          <Link href={`/${locale}/founder`} className="hover:text-[#242424] transition-colors">بطاقة المؤسسين</Link>
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden md:flex gap-2 text-xs">
            {locales.map((l) => (
              <Link key={l} href={to(l)} className={`px-2 py-1 ${l === locale ? "bg-[#242424] text-[#FAF7F2]" : "text-[#B9A18D] hover:text-[#242424]"}`}>
                {l.toUpperCase()}
              </Link>
            ))}
          </div>

          <Link href={`/${locale}/wishlist`} aria-label="المفضلة" className="relative p-2.5 rounded-full hover:bg-[#F3EBDD] transition-colors text-[#242424]">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.6" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
            </svg>
          </Link>

          <Link href={`/${locale}/account`} aria-label="الحساب" className="p-2.5 rounded-full hover:bg-[#F3EBDD] transition-colors text-[#242424] hidden sm:inline-flex">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.6" viewBox="0 0 24 24">
              <circle cx="12" cy="8" r="4" />
              <path d="M4 20c0-4 4-6 8-6s8 2 8 6" />
            </svg>
          </Link>

          <Link href={`/${locale}/cart`} aria-label="حقيبة التسوق" className="relative flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#242424] text-[#FAF7F2] hover:bg-[#242424]/90 transition-all shadow-sm">
            <svg className="w-4 h-4 text-[#D9C7AD]" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007z" />
            </svg>
            <span className="text-xs sm:text-sm font-medium">الحقيبة</span>
          </Link>

          <MobileMenu locale={locale} messages={messages} to={to} />
        </div>
      </div>
    </header>
  );
}
