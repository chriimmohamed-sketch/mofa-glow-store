export interface CampaignDay { day: number; title: string; type: string; visual: string; text: string; cta: string; }
export const campaign: Record<"ar" | "fr" | "en", { intro: string; note: string; days: CampaignDay[] }> = {
  ar: { intro: "سبعة أيام من البداية... والباقي غادي نبنيوه معاكم.", note: "خطة محتوى مرحلية؛ المنتجات غير متاحة بعد، وما كنعرضو حتى عبوة وهمية.", days: [
    { day: 1, title: "إعلان الهوية", type: "منشور + TikTok", visual: "خلفية بيج بملمس وراقي، إضاءة ناعمة، اسم MOFA GLOW بخط Serif.", text: "شي حاجة جديدة كتوجد، برؤية مختلفة للجمال والأناقة. Meet MOFA GLOW. Your Skin. Your Glow.", cta: "تابعونا، البداية ما زالت أمامنا." },
    { day: 2, title: "قصة العلامة", type: "Reel 10–15 ثانية", visual: "ضوء الشمس فوق خلفية بيج، قماش ناعم، ظهور الاسم ثم الشعار.", text: "بالنسبة لينا، البداية ماشي هي المنتج، البداية هي الفكرة.", cta: "شنو كيعني ليك الجمال الحقيقي؟" },
    { day: 3, title: "فلسفة MOFA GLOW", type: "Carousel 3 شرائح", visual: "Beauty is not a trend / It's a feeling / It's confidence. It's you.", text: "الجمال ماشي منافسة، وماشي معايير مفروضة.", cta: "مظهر، إحساس، ولا بجوج؟" },
    { day: 4, title: "استكشاف الجمهور", type: "Stories واستطلاعات", visual: "خلفية محايدة، سؤال واضح، Poll و Question Box.", text: "قبل ما نختارو أول اتجاه، بغينا نسمعو ليكم.", cta: "صوتك يقدر يساهم في بناء العلامة." },
    { day: 5, title: "الشفافية والثقة", type: "منشور ثابت", visual: "ورق Ivory، ضوء طبيعي، جملة قصيرة بارزة.", text: "الثقة كتتبنى بالوضوح والصدق مع الناس.", cta: "شنو كيخليك تثق فبراند جديد؟" },
    { day: 6, title: "التشويق", type: "Reel 8–10 ثوانٍ", visual: "لقطة سوداء، انتقال إلى Champagne Beige، ثم A NEW CHAPTER.", text: "Something beautiful is on the horizon.", cta: "فعّل الإشعارات." },
    { day: 7, title: "دعوة للمشاركة", type: "منشور تفاعلي", visual: "الشعار اللفظي مع سؤال مفتوح.", text: "7 أيام من البداية... الباقي غادي نبنيوه معاكم.", cta: "شارك المنشور." } ] },
  fr: { intro: "7 jours depuis le début... la suite, on la construira avec vous.", note: "Plan de contenu étape par étape ; aucun faux emballage n'est montré.", days: [
    { day: 1, title: "Annonce de l'identité", type: "Post Instagram + TikTok", visual: "Fond beige texturé, lumière douce, nom en Serif.", text: "Something new is taking shape. Your Skin. Your Glow.", cta: "Suivez-nous." },
    { day: 2, title: "L'histoire", type: "Reel 10–15 s", visual: "Lumière sur fond beige, apparition du nom.", text: "Le commencement n'est pas le produit, c'est l'idée.", cta: "Que signifie la beauté pour vous ?" },
    { day: 3, title: "La philosophie", type: "Carrousel", visual: "Beauty is not a trend / It's a feeling.", text: "La beauté n'est pas une compétition.", cta: "Apparence, sensation, ou les deux ?" },
    { day: 4, title: "Rencontre du public", type: "Stories et sondages", visual: "Fond neutre, question claire.", text: "Nous voulons vous écouter.", cta: "Votre avis compte." },
    { day: 5, title: "Transparence", type: "Post fixe", visual: "Papier Ivory, lumière naturelle.", text: "La confiance se construit avec clarté.", cta: "Qu'est-ce qui vous fait confiance ?" },
    { day: 6, title: "Teasing", type: "Reel 8–10 s", visual: "Noir puis Champagne Beige.", text: "Something beautiful is on the horizon.", cta: "Activez les notifications." },
    { day: 7, title: "Participation", type: "Post interactif", visual: "Slogan et question ouverte.", text: "La suite se construit avec vous.", cta: "Partagez." } ] },
  en: { intro: "7 days from the beginning... the rest we build together.", note: "Phased content plan; products are not available yet and no fake packaging is shown.", days: [
    { day: 1, title: "Identity announcement", type: "Post + TikTok", visual: "Textured beige, soft light, serif name.", text: "Something new is taking shape. Your Skin. Your Glow.", cta: "Follow us." },
    { day: 2, title: "Brand story", type: "10–15s Reel", visual: "Sunlight on beige, name appears.", text: "The beginning is not the product — it's the idea.", cta: "What does real beauty mean to you?" },
    { day: 3, title: "Philosophy", type: "Carousel", visual: "Beauty is not a trend / It's a feeling.", text: "Beauty is not competition.", cta: "Appearance, feeling, or both?" },
    { day: 4, title: "Audience discovery", type: "Stories and polls", visual: "Neutral background, clear question.", text: "We want to hear from you.", cta: "Your voice matters." },
    { day: 5, title: "Transparency", type: "Static post", visual: "Ivory paper, natural light.", text: "Trust is built with clarity.", cta: "What makes you trust a brand?" },
    { day: 6, title: "Teaser", type: "8–10s Reel", visual: "Black then Champagne Beige.", text: "Something beautiful is on the horizon.", cta: "Turn on notifications." },
    { day: 7, title: "Call to participate", type: "Interactive post", visual: "Slogan with open question.", text: "The rest we build with you.", cta: "Share this." } ] },
};