import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function PolicyLayout({ locale, messages, title, children }: { locale: string; messages: any; title: string; children: React.ReactNode }) {
  return (
    <>
      <Header locale={locale} messages={messages} />
      <main className="container py-16 max-w-3xl">
        <div className="eyebrow mb-3">MOFA GLOW</div>
        <h1 className="font-display display-md mb-8">{title}</h1>
        <div className="prose-policy space-y-5 text-[var(--muted)] text-sm leading-relaxed">{children}</div>
      </main>
      <Footer locale={locale} messages={messages} />
    </>
  );
}