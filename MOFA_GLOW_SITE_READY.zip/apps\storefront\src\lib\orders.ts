export interface LocalOrder {
  id: string;
  createdAt: string;
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled";
  payment: "cod" | "online";
  items: Array<{ productId: string; slug: string; name: string; price: number; qty: number }>;
  total: number;
  customer: { firstName: string; lastName: string; phone: string; address: string; city: string; email: string };
  source: "local-preview";
}

const KEY = "mg_orders";

export function saveLocalOrder(order: LocalOrder) {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(KEY);
    const list: LocalOrder[] = raw ? JSON.parse(raw) : [];
    localStorage.setItem(KEY, JSON.stringify([order, ...list].slice(0, 20)));
  } catch {}
}

export function getLocalOrders(): LocalOrder[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}
