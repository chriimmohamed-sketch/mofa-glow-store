"use client";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
interface Ctx { ids: string[]; toggle: (id: string) => void; has: (id: string) => boolean; }
const C = createContext<Ctx | null>(null);
export function WishlistProvider({ children }: { children: ReactNode }) {
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => { try { const r = localStorage.getItem("mg_wishlist"); if (r) setIds(JSON.parse(r)); } catch {} }, []);
  useEffect(() => { localStorage.setItem("mg_wishlist", JSON.stringify(ids)); }, [ids]);
  const toggle = (id: string) => setIds((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id]);
  return <C.Provider value={{ ids, toggle, has: (id) => ids.includes(id) }}>{children}</C.Provider>;
}
export function useWishlist() { const c = useContext(C); if (!c) throw new Error("useWishlist outside provider"); return c; }
