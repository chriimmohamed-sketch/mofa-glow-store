"use client";
import { useState } from "react";

export default function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const set = (k: string) => (e: any) => setForm({ ...form, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setState("loading");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.message || d.error);
      setState("done"); setMessage(d.message); setForm({ name: "", email: "", message: "" });
    } catch (err: any) { setState("error"); setMessage(err.message); }
  }

  return (
    <form onSubmit={submit} className="mt-10 space-y-4">
      <input className="field-input" placeholder="Your name" required value={form.name} onChange={set("name")} />
      <input className="field-input" type="email" placeholder="Your email" required value={form.email} onChange={set("email")} />
      <textarea className="field-input" rows={5} placeholder="Your message" required value={form.message} onChange={set("message")} />
      {message && <p role={state === "error" ? "alert" : "status"} className="text-xs text-[var(--accent)]">{message}</p>}
      <button type="submit" disabled={state === "loading"} className="btn btn-primary">
        {state === "loading" ? "..." : "Send message"}
      </button>
    </form>
  );
}