<?php
class MOFAGLOW_SpaceSeller_Adapter {
  private $base, $key;
  public function __construct() { $this->base = get_option( 'mofaglow_spaceseller_base_url', '' ); $this->key = get_option( 'mofaglow_spaceseller_api_key', '' ); }
  public function is_configured() { return ! empty( $this->base ) && ! empty( $this->key ); }
  public function test_connection() { return array( 'ok' => false, 'message' => 'Not implemented: awaiting official SpaceSeller documentation. No undocumented calls made.' ); }
  public function sync_order( $order_id ) {
    if ( ! $this->is_configured() ) return array( 'success' => false, 'error' => 'not_configured' );
    $existing = get_post_meta( $order_id, '_mofaglow_spaceseller_order_id', true );
    if ( $existing ) return array( 'success' => true, 'external_order_id' => $existing, 'skipped' => true );
    return array( 'success' => false, 'error' => 'not_implemented' );
  }
  public function sync_status() { return array( 'success' => false, 'error' => 'not_implemented' ); }
}