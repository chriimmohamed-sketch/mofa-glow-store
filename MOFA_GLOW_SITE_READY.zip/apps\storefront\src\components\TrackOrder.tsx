"use client";
import { useState } from "react";
import { getLocalOrders } from "@/lib/orders";

export default function TrackOrder() {
  const [ref, setRef] = useState("");
  const [result, setResult] = useState<"idle" | "found" | "missing">("idle");
  const steps = ["pending", "processing", "shipped", "delivered"];

  function search(e: React.FormEvent) {
    e.preventDefault();
    const order = getLocalOrders().find((o) => o.id.toLowerCase() === ref.trim().toLowerCase());
    setResult(order ? "found" : "missing");
  }

  return (
    <div className="max-w-2xl">
      <form onSubmit={search} className="flex gap-3">
        <input
          value={ref}
          onChange={(e) => setRef(e.target.value)}
          placeholder="Order reference (e.g. MG-...)"
          className="field-input flex-1"
          required
        />
        <button type="submit" className="btn btn-primary">Track</button>
      </form>
      {result === "missing" && <p className="mt-5 text-sm text-[var(--muted)]">No local order with that reference was found on this device.</p>}
      {result === "found" && (
        <div className="card p-6 mt-6">
          <div className="font-display text-xl mb-4">{ref.trim()}</div>
          <div className="flex gap-2">
            {steps.map((s, i) => (
              <div key={s} className="flex-1">
                <div className={`h-1 ${i === 0 ? "bg-[var(--accent)]" : "bg-[var(--line)]"}`} />
                <div className="text-[.65rem] mt-1 text-[var(--muted)] capitalize">{s}</div>
              </div>
            ))}
          </div>
          <p className="text-xs text-[var(--muted)] mt-5">
            Live tracking requires the WooCommerce/shipping connection. This shows the local preview status only.
          </p>
        </div>
      )}
    </div>
  );
}