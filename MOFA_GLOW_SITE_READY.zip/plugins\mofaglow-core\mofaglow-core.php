<?php
/**
 * Plugin Name: MOFA GLOW Core
 * Description: Suppliers, product sources, margins, sync, logs, survey, admin.
 * Version: 0.1.0
 * Author: MOFA GLOW
 */
if ( ! defined( 'ABSPATH' ) ) exit;
define( 'MOFAGLOW_CORE_VERSION', '0.1.0' );
define( 'MOFAGLOW_CORE_PATH', plugin_dir_path( __FILE__ ) );
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-db.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-suppliers.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-product-source.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-profit.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-sync-log.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-spaceseller-adapter.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-survey.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-admin.php';
require_once MOFAGLOW_CORE_PATH . 'includes/class-mofaglow-rest.php';
register_activation_hook( __FILE__, array( 'MOFAGLOW_DB', 'activate' ) );
register_activation_hook( __FILE__, array( 'MOFAGLOW_Survey', 'activate' ) );
add_action( 'plugins_loaded', function () { MOFAGLOW_Admin::init(); MOFAGLOW_REST::init(); MOFAGLOW_Survey::init(); } );
