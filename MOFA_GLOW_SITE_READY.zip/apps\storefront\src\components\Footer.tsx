import Link from "next/link";

export default function Footer({ locale, messages }: { locale: string; messages: any }) {
  return (
    <footer className="bg-[#242424] text-[#FAF7F2]/85 py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-10 border-b border-[#B9A18D]/20">
          <div>
            <span className="tracking-[0.25em] text-2xl text-[#FAF7F2] block">MOFA GLOW</span>
            <p className="text-xs text-[#D9C7AD] mt-1.5">Your Skin. Your Glow. — بشرتكِ، إشراقتكِ</p>
          </div>
          <div className="flex flex-wrap gap-6 text-xs text-[#FAF7F2]/70">
            <Link href={`/${locale}/shop`} className="hover:text-[#D9C7AD] transition-colors">الكتالوج الكامل</Link>
            <Link href={`/${locale}/collections`} className="hover:text-[#D9C7AD] transition-colors">المجموعات</Link>
            <Link href={`/${locale}/philosophy`} className="hover:text-[#D9C7AD] transition-colors">فلسفة التركيبات</Link>
            <Link href={`/${locale}/founder`} className="hover:text-[#D9C7AD] transition-colors">بطاقة المؤسسين</Link>
            <Link href={`/${locale}/cart`} className="hover:text-[#D9C7AD] transition-colors">سلة المشتريات</Link>
          </div>
        </div>
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#FAF7F2]/50">
          <p>© 2026 MOFA GLOW Maroc. جميع الحقوق محفوظة.</p>
          <p>كود الخصم الترحيبي: <span className="text-[#D9C7AD] tracking-wider">GLOW2026</span> (خصم 15%)</p>
        </div>
      </div>
    </footer>
  );
}
