import { getSupabase, isSupabaseConfigured } from "./supabase";
const getClient = () => getSupabase();
import { localProducts, type Product } from "./products";

export type { Product };

export async function fetchProducts(): Promise<Product[]> {
  if (!isSupabaseConfigured()) {
    return localProducts;
  }
  try {
    const { data, error } = await getClient()!
      .from("mg_products")
      .select("*")
      .order("created_at", { ascending: true });

    if (error || !data || data.length === 0) {
      return localProducts;
    }

    return data.map((row: any) => ({
      id: row.id,
      sku: row.sku,
      slug: row.slug,
      name: row.name,
      nameFr: row.name_fr || row.name,
      description: row.description || "",
      subtitle: row.subtitle || "",
      category: row.category,
      categoryLabel: row.category_label || row.category,
      volume: row.volume || "",
      price: Number(row.price),
      cost: Number(row.cost),
      currency: row.currency || "MAD",
      source: row.source || "OWN_BRAND",
      inStock: row.in_stock ?? true,
      images: Array.isArray(row.images) ? row.images : [],
      badge: row.badge || "",
      ingredients: Array.isArray(row.ingredients) ? row.ingredients : [],
      ritual: row.ritual || "",
      packagingDesc: row.packaging_desc || "",
      estimatedDeliveryDays: row.estimated_delivery_days || 3,
    }));
  } catch {
    return localProducts;
  }
}

export async function fetchProductBySlug(slug: string): Promise<Product | null> {
  if (!isSupabaseConfigured()) {
    return localProducts.find((p) => p.slug === slug) || null;
  }
  try {
    const { data, error } = await getClient()!
      .from("mg_products")
      .select("*")
      .eq("slug", slug)
      .single();

    if (error || !data) {
      return localProducts.find((p) => p.slug === slug) || null;
    }

    return {
      id: data.id,
      sku: data.sku,
      slug: data.slug,
      name: data.name,
      nameFr: data.name_fr || data.name,
      description: data.description || "",
      subtitle: data.subtitle || "",
      category: data.category,
      categoryLabel: data.category_label || data.category,
      volume: data.volume || "",
      price: Number(data.price),
      cost: Number(data.cost),
      currency: data.currency || "MAD",
      source: data.source || "OWN_BRAND",
      inStock: data.in_stock ?? true,
      images: Array.isArray(data.images) ? data.images : [],
      badge: data.badge || "",
      ingredients: Array.isArray(data.ingredients) ? data.ingredients : [],
      ritual: data.ritual || "",
      packagingDesc: data.packaging_desc || "",
      estimatedDeliveryDays: data.estimated_delivery_days || 3,
    };
  } catch {
    return localProducts.find((p) => p.slug === slug) || null;
  }
}

export async function createOrder(order: {
  reference: string;
  customer: { firstName: string; lastName: string; phone: string; email: string; address: string; city: string };
  items: Array<{ productId: string; name: string; sku?: string; price: number; qty: number }>;
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: string;
}): Promise<{ success: boolean; reference: string; error?: string }> {
  if (!isSupabaseConfigured()) {
    return { success: true, reference: order.reference };
  }
  try {
    const { data: orderData, error: orderError } = await getClient()!
      .from("mg_orders")
      .insert({
        reference: order.reference,
        customer_first_name: order.customer.firstName,
        customer_last_name: order.customer.lastName,
        customer_phone: order.customer.phone,
        customer_email: order.customer.email,
        customer_address: order.customer.address,
        customer_city: order.customer.city,
        payment_method: order.paymentMethod,
        subtotal: order.subtotal,
        shipping_fee: order.shippingFee,
        total: order.total,
        status: "pending",
      })
      .select()
      .single();

    if (orderError || !orderData) {
      return { success: false, reference: order.reference, error: orderError?.message || "Order creation failed" };
    }

    // Insert order items
    const orderItems = order.items.map((item) => ({
      order_id: orderData.id,
      product_id: item.productId || null,
      product_name: item.name,
      product_sku: item.sku || null,
      price: item.price,
      qty: item.qty,
    }));

    const { error: itemsError } = await getClient()!.from("mg_order_items").insert(orderItems);

    if (itemsError) {
      return { success: false, reference: order.reference, error: itemsError.message };
    }

    // Log audit
    await getClient()!.from("mg_audit_logs").insert({
      action: "order_created",
      entity_type: "order",
      entity_id: orderData.id,
      details: { reference: order.reference, total: order.total, items: order.items.length },
    });

    return { success: true, reference: order.reference };
  } catch (err: any) {
    return { success: false, reference: order.reference, error: err.message };
  }
}

export async function subscribeNewsletter(email: string, locale: string): Promise<{ success: boolean; error?: string }> {
  if (!isSupabaseConfigured()) {
    return { success: false, error: "Supabase not configured" };
  }
  try {
    const { error } = await getClient()!.from("mg_newsletter_subscribers").insert({ email, locale });
    if (error) {
      if (error.code === "23505") return { success: true }; // Already subscribed
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function submitContactMessage(name: string, email: string, message: string): Promise<{ success: boolean; error?: string }> {
  if (!isSupabaseConfigured()) {
    return { success: false, error: "Supabase not configured" };
  }
  try {
    const { error } = await getClient()!.from("mg_contact_messages").insert({ name, email, message });
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

