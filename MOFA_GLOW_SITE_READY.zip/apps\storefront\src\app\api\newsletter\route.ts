import { NextResponse } from "next/server";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { subscribeNewsletter } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/supabase";

export async function POST(request: Request) {
  const gate = rateLimit(`${clientKey(request)}:newsletter`, 5, 60_000);
  if (!gate.allowed) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  let body: any;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "invalid_json" }, { status: 400 }); }

  const email = typeof body.email === "string" ? body.email.trim() : "";
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ error: "invalid_email" }, { status: 400 });
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json({ error: "newsletter_backend_not_configured", message: "Newsletter is not connected yet. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY." }, { status: 503 });
  }

  const result = await subscribeNewsletter(email, body.locale || "ar");
  if (!result.success) {
    return NextResponse.json({ error: "subscription_failed", message: result.error || "Could not subscribe." }, { status: 500 });
  }
  return NextResponse.json({ message: "Subscribed successfully." });
}
