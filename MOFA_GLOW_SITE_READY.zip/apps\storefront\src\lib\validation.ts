export const MOROCCAN_PHONE = /^(?:\+212|0)[1-9]\d{8}$/;
export const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export function isValidMoroccanPhone(value: string) {
  return MOROCCAN_PHONE.test(value.replace(/[\s-]/g, ""));
}

export function isValidEmail(value: string) {
  return EMAIL.test(value.trim());
}

export function sanitizeText(value: string, max = 500) {
  return value.replace(/[<>]/g, "").trim().slice(0, max);
}