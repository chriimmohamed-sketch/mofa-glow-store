# SpaceSeller Integration

Status: NOT VERIFIED. Adapter disabled; no undocumented calls.

## Verified from official public site (spaceseller.ma)
- Moroccan private-label/dropshipping platform (Ste Space Seller SARL, Agadir).
- Handles production, packaging, customer confirmation, delivery.
- Merchant dashboard: https://drop.spaceseller.ma/admin/login
- Contact: WhatsApp +212 646 704 070.
- States it integrates with e-commerce platforms, but publishes no API docs, auth scheme, endpoints or webhook spec.

## Required before implementation
Merchant account access; official docs for auth method, required WooCommerce API permissions, order payload, status updates, webhook signatures; a test product and test order.

Design ready: `SpaceSellerAdapter` (Next.js) + `MOFAGLOW_SpaceSeller_Adapter` (WP) with `testConnection`, `syncOrder`, `syncOrderStatus`, idempotency via `external_order_id`, server-side secrets.
