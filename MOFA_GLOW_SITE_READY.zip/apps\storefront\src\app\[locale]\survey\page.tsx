import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SurveyClient from "@/components/SurveyClient";
export default async function SurveyPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params; const l = isLocale(locale) ? locale : "ar"; const m = await getMessages(l);
  return <><Header locale={l} messages={m} /><main className="container py-12">
    <div className="eyebrow mb-3">MOFA GLOW — AUDIENCE RESEARCH</div><h1 className="font-display text-4xl mb-3">Help us shape the future of beauty</h1>
    <p className="text-[var(--muted)] mb-8 max-w-2xl">Anonymous by default. No email required — only provide it if you explicitly opt in.</p>
    <SurveyClient />
  </main><Footer locale={l} messages={m} /></>;
}