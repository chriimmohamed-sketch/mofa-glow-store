"use client";
import Link from "next/link";
import { useCart } from "@/lib/cart";
import { cartTotals } from "@/lib/cart-math";
import { formatMAD } from "@/lib/money";
import { products } from "@/lib/products";

export default function CartClient({ locale, labels }: { locale: string; labels: any }) {
  const { items, add, remove, clear } = useCart();
  const t = cartTotals(items.map((i) => ({ productId: i.productId, price: i.price, qty: i.qty })));
  if (!items.length)
    return (
      <div className="text-center py-20 bg-[#F3EBDD]/50 rounded-3xl border border-[#D9C7AD]/50">
        <p className="font-serif text-2xl text-[#242424] mb-3">حقيبتكِ فارغة حالياً</p>
        <p className="text-sm text-[#242424]/65 mb-6">اختاري من بين 8 تركيبات فاخرة للعناية ببشرتكِ.</p>
        <Link href={`/${locale}/shop`} className="px-8 py-4 rounded-full bg-[#242424] text-[#FAF7F2] text-sm font-medium hover:bg-[#242424]/90 transition-all shadow-md inline-block">
          استكشاف المنتجات
        </Link>
      </div>
    );
  return (
    <div className="grid md:grid-cols-[1fr_360px] gap-8">
      <div className="space-y-4">
        {items.map((i) => {
          const prod = products.find((x) => x.slug === i.slug);
          return (
            <div key={i.productId} className="flex items-center gap-4 bg-[#FAF7F2]/70 p-4 rounded-2xl border border-[#D9C7AD]/60">
              <div className="w-20 h-20 rounded-xl overflow-hidden border border-[#D9C7AD]/60 shrink-0 bg-[#F3EBDD]">
                {prod?.images[0] ? (
                  <img src={prod.images[0]} alt={i.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center font-serif text-2xl text-[#B38A4C]">{i.name.charAt(0)}</div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <Link href={`/${locale}/product/${i.slug}`} className="font-serif text-lg text-[#242424] hover:text-[#B38A4C] transition-colors truncate block">{i.name}</Link>
                <div className="text-xs text-[#B9A18D] font-medium mt-0.5">{formatMAD(i.price, locale)}</div>
              </div>
              <div className="inline-flex items-center border border-[#D9C7AD] rounded-full bg-[#FAF7F2]">
                <button type="button" className="w-8 h-8 text-sm text-[#242424] hover:bg-[#F3EBDD] rounded-r-full" onClick={() => i.qty > 1 ? add({ productId: i.productId, slug: i.slug, name: i.name, price: i.price }, -1) : remove(i.productId)}>−</button>
                <span className="w-8 text-center text-sm font-bold">{i.qty}</span>
                <button type="button" className="w-8 h-8 text-sm text-[#242424] hover:bg-[#F3EBDD] rounded-l-full" onClick={() => add({ productId: i.productId, slug: i.slug, name: i.name, price: i.price }, 1)}>+</button>
              </div>
              <button type="button" onClick={() => remove(i.productId)} className="text-xs text-[#242424]/60 hover:text-[#242424] underline">حذف</button>
            </div>
          );
        })}
        <button type="button" onClick={clear} className="text-xs text-[#242424]/60 hover:text-[#242424] underline">حذف الكل</button>
      </div>
      <aside className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#D9C7AD]/60 h-fit sticky top-24">
        <h2 className="font-serif text-xl text-[#242424] mb-4">ملخص الطلب</h2>
        <div className="flex justify-between mb-2 text-sm"><span>المجموع الفرعي</span><span className="font-medium">{formatMAD(t.subtotal, locale)}</span></div>
        <div className="flex justify-between mb-2 text-sm text-[#242424]/60"><span>التوصيل</span><span>{t.subtotal >= 400 ? "مجاني" : "35 درهم"}</span></div>
        {t.subtotal < 400 && (
          <p className="text-xs text-[#242424]/60 mb-3">أضيفي منتجات بقيمة {400 - t.subtotal} درهم للحصول على توصيل مجاني!</p>
        )}
        <div className="flex justify-between border-t border-[#D9C7AD]/60 pt-4 mt-4 font-bold text-lg">
          <span>الإجمالي</span>
          <span className="font-serif">{formatMAD(t.subtotal + (t.subtotal >= 400 ? 0 : 35), locale)}</span>
        </div>
        <Link href={`/${locale}/checkout`} className="block w-full mt-6 py-4 rounded-full bg-[#242424] text-[#FAF7F2] text-sm font-medium hover:bg-[#242424]/90 transition-all shadow-md text-center">
          إتمام الطلب (الدفع عند الاستلام)
        </Link>
      </aside>
    </div>
  );
}
