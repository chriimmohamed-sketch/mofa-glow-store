"use client";
import Link from "next/link";
import { useWishlist } from "@/lib/wishlist";
import { products } from "@/lib/products";
import { formatMAD } from "@/lib/money";
import WishlistButton from "@/components/WishlistButton";
export default function WishlistClient({ locale }: { locale: string }) {
  const { ids } = useWishlist(); const items = products.filter((p) => ids.includes(p.id));
  if (!items.length) return <div className="card p-10 text-center text-[var(--muted)]">—</div>;
  return <div className="grid grid-cols-2 md:grid-cols-4 gap-5">{items.map((p) => <div key={p.id} className="card p-4 relative">
    <div className="absolute top-3 end-3 z-10"><WishlistButton productId={p.id} /></div>
    <Link href={`/${locale}/product/${p.slug}`}><div className="aspect-square bg-[var(--surface-2)] mb-4 overflow-hidden">{p.images[0] ? <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center font-display text-5xl text-[var(--accent)]">{p.name.charAt(0)}</div>}</div><div className="font-display text-lg mb-1">{p.name}</div></Link>
    <div className="price">{formatMAD(p.price, locale)}</div>
  </div>)}</div>;
}