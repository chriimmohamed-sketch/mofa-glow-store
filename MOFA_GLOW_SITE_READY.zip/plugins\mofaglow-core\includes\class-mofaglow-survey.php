<?php
class MOFAGLOW_Survey {
  public static function table() { global $wpdb; return $wpdb->prefix . 'mofaglow_survey_responses'; }
  public static function activate() {
    global $wpdb; $sql = "CREATE TABLE " . self::table() . " (id bigint(20) unsigned NOT NULL AUTO_INCREMENT, locale varchar(8) NOT NULL DEFAULT 'ar', category varchar(64) NOT NULL, factor varchar(64) NOT NULL, price_range varchar(64) DEFAULT NULL, missing text DEFAULT NULL, first_product text DEFAULT NULL, local_brand varchar(16) DEFAULT NULL, consent tinyint(1) NOT NULL DEFAULT 0, email varchar(191) DEFAULT NULL, created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY created_at (created_at)) " . $wpdb->get_charset_collate() . ";";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php'; dbDelta( $sql );
  }
  public static function init() { add_action( 'rest_api_init', array( __CLASS__, 'routes' ) ); }
  public static function routes() { register_rest_route( 'mofaglow/v1', '/survey', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'submit' ), 'permission_callback' => '__return_true' ) ); }
  public static function submit( $request ) {
    $p = $request->get_json_params(); if ( ! is_array( $p ) ) return new WP_Error( 'invalid_body', 'Invalid body', array( 'status' => 400 ) );
    if ( ! empty( $p['website'] ) ) return rest_ensure_response( array( 'ok' => true ) );
    $cat = sanitize_key( $p['category'] ?? '' ); $factor = sanitize_key( $p['factor'] ?? '' );
    if ( ! $cat || ! $factor ) return new WP_Error( 'missing_required', 'Missing required fields', array( 'status' => 400 ) );
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown'; $key = 'mofaglow_survey_' . md5( $ip );
    $count = (int) get_transient( $key ); if ( $count >= 5 ) return new WP_Error( 'too_many', 'Too many', array( 'status' => 429 ) );
    set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );
    $consent = ! empty( $p['consentToContact'] ); global $wpdb;
    $wpdb->insert( self::table(), array( 'locale' => in_array( $p['locale'] ?? 'ar', array('ar','fr','en'), true ) ? $p['locale'] : 'ar', 'category' => $cat, 'factor' => $factor, 'price_range' => sanitize_text_field( $p['priceRange'] ?? '' ), 'missing' => sanitize_textarea_field( $p['missing'] ?? '' ), 'first_product' => sanitize_textarea_field( $p['firstProduct'] ?? '' ), 'local_brand' => sanitize_key( $p['localBrand'] ?? '' ), 'consent' => $consent ? 1 : 0, 'email' => $consent ? sanitize_email( $p['email'] ?? '' ) : '' ) );
    return rest_ensure_response( array( 'ok' => true, 'message' => 'Merci — votre réponse a été enregistrée.' ) );
  }
}