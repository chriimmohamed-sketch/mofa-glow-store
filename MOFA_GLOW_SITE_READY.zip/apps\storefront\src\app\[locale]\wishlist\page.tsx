import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WishlistClient from "@/components/WishlistClient";
export default async function WishlistPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params; const l = isLocale(locale) ? locale : "ar"; const m = await getMessages(l);
  return <><Header locale={l} messages={m} /><main className="container py-12"><h1 className="font-display text-3xl mb-8">{m.nav.wishlist}</h1><WishlistClient locale={l} /></main><Footer locale={l} messages={m} /></>;
}