# Catalogue Curation — SpaceSeller

## Access note
The requested URL `https://drop.spaceseller.ma/admin/onboarding` requires an authenticated merchant account.
It could not be opened from this environment (no credentials; browser navigation blocked). No data was invented.

The **public catalogue** at `https://spaceseller.ma/catalogue/` is accessible and lists 184 products.

## Selected formulas (public catalogue, cosmetics/skincare focus)
- Niacinamide serum → reimagined as **Clarity Niacinamide Serum**
- Retinol cream → reimagined as **Renewal Retinol Night Cream**
- Moisturizing Hair Mask → reimagined as **Silk Repair Hair Mask**
- Botanical care oil → reimagined as **Soothe Botanical Oil**

Selection rationale: aligned with MOFA GLOW's official positioning (beauty & skincare, quiet luxury,
Moroccan market), low-risk cosmetic claims, and suitable for the DROPSHIPPING business model.

## What was changed for MOFA GLOW
- Original product names, descriptions, MAD pricing and categories
- Custom MOFA GLOW SVG packaging artwork (ivory/gold, droplet mark, serif wordmark)
- Positioning as "curated & reimagined" supplier formulas — no fake MOFA manufacturing claims
- Supplier identity and purchase cost remain server-side only

## Not done
- No merchant dashboard "trending" data was available; "leading products" were selected by brand fit, not sales rank.
- No supplier order was placed and no fulfillment was verified.
- Real product photography is still needed before launch.
