# MOFA GLOW

Independent premium e-commerce platform for Morocco (MAD). Headless hybrid commerce:
Next.js storefront + WordPress/WooCommerce + custom `mofaglow-core` plugin.

## Run locally
cd apps/storefront
npm install
npm run dev
Open http://localhost:3000/ar (or /fr, /en). `/` redirects to Arabic.

## Structure
- apps/storefront — Next.js (TypeScript, Tailwind) customer storefront
- plugins/mofaglow-core — WordPress business plugin
- docs/ — architecture, database, API, security, deployment, SpaceSeller, payments, brand, status
- tests/ — unit tests

## Honest status
Not production-ready until WooCommerce credentials, SpaceSeller docs, a verified Moroccan payment provider,
and Cloudflare/domain access are provided. See docs/FINAL-STATUS.md.
