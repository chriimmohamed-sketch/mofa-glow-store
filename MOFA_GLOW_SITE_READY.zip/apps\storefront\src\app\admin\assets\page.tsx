import fs from "fs";
import path from "path";
import Link from "next/link";

export const metadata = { title: "Assets" };

export default function AssetsPage() {
  const dir = path.join(process.cwd(), "public", "images", "uploads");
  let files: string[] = [];
  try {
    files = fs.readdirSync(dir).filter((f) => /\.(jfif|jpg|jpeg|png|webp|svg)$/i.test(f));
  } catch {}
  return (
    <div style={{ fontFamily: "system-ui, sans-serif", padding: 24, background: "#f6f2ea", minHeight: "100vh" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h1 style={{ margin: 0, fontSize: 28 }}>Uploaded Assets ({files.length})</h1>
          <Link href="/admin" style={{ color: "#7a5a2e" }}>← Command Center</Link>
        </div>
        <p style={{ color: "#555", marginBottom: 24 }}>Review filenames and tell me which image belongs to which product/section.</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 16 }}>
          {files.map((f) => (
            <figure key={f} style={{ margin: 0, background: "#fff", border: "1px solid #ddd", padding: 10 }}>
              <img src={`/images/uploads/${f}`} alt={f} style={{ width: "100%", height: 220, objectFit: "cover", background: "#eee" }} />
              <figcaption style={{ fontSize: 11, marginTop: 8, wordBreak: "break-all", color: "#333" }}>{f}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </div>
  );
}
