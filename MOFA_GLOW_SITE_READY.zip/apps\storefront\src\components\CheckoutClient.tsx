"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { useCart } from "@/lib/cart";
import { cartTotals } from "@/lib/cart-math";
import { formatMAD } from "@/lib/money";
import { saveLocalOrder } from "@/lib/orders";
import { products } from "@/lib/products";

const CITIES = ["الدار البيضاء", "الرباط", "مراكش", "أكادير", "طنجة", "فاس", "مكناس", "وجدة", "القنيطرة", "تطوان", "آسفي", "الجديدة", "أخرى"];
const MOROCCAN_PHONE = /^(?:\+212|0)[1-9]\d{8}$/;

export default function CheckoutClient({ locale, labels }: { locale: string; labels: any }) {
  const { items, clear } = useCart();
  const totals = cartTotals(items.map((i) => ({ productId: i.productId, price: i.price, qty: i.qty })));
  const [form, setForm] = useState({ firstName: "", lastName: "", phone: "", address: "", city: "الدار البيضاء", email: "" });
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [reference, setReference] = useState("");
  const set = (k: string) => (e: any) => setForm({ ...form, [k]: e.target.value });

  const phoneValid = useMemo(() => MOROCCAN_PHONE.test(form.phone.replace(/\s/g, "")), [form.phone]);
  const shippingFee = totals.subtotal >= 400 ? 0 : 35;
  const finalTotal = totals.subtotal + shippingFee;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!phoneValid) {
      setState("error");
      setMessage("أدخل رقم هاتف مغربي صحيح (مثال: 06XXXXXXXX أو +2126XXXXXXXX).");
      return;
    }
    setState("loading");
    const ref = `MG-${Date.now().toString(36).toUpperCase()}`;
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customer: form, payment: "cod", items, reference: ref }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || data.error);
      saveLocalOrder({ id: ref, createdAt: new Date().toISOString(), status: "pending", payment: "cod", items, total: finalTotal, customer: form, source: "local-preview" });
      setReference(ref);
      setState("done");
      clear();
    } catch (err: any) {
      saveLocalOrder({ id: ref, createdAt: new Date().toISOString(), status: "pending", payment: "cod", items, total: finalTotal, customer: form, source: "local-preview" });
      setReference(ref);
      setState("done");
      setMessage(`تم حفظ الطلب كمعاينة محلية (${ref}). إنشاء الطلب الحقيقي يتطلب ربط WooCommerce.`);
    }
  }

  if (state === "done") {
    return (
      <div className="text-center py-16 bg-[#F3EBDD]/50 rounded-3xl border border-[#D9C7AD]/50 max-w-2xl mx-auto">
        <div className="w-16 h-16 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center mx-auto text-2xl mb-4">✓</div>
        <h2 className="font-serif text-2xl text-[#242424] mb-3">تم تأكيد طلبكِ بنجاح!</h2>
        <p className="text-sm text-[#242424]/70 mb-2">رقم الطلب: <strong className="font-mono text-[#242424]">{reference}</strong></p>
        {message && <p className="text-xs text-[#242424]/60 mt-3 max-w-md mx-auto">{message}</p>}
        <Link href={`/${locale}/shop`} className="mt-6 px-8 py-3 rounded-full bg-[#242424] text-[#FAF7F2] text-sm font-medium hover:bg-[#242424]/90 transition-all shadow-md inline-block">
          متابعة التسوق
        </Link>
      </div>
    );
  }

  const input = "w-full bg-[#FAF7F2] border border-[#D9C7AD] rounded-xl px-4 py-3 text-sm text-[#242424] focus:outline-none focus:border-[#242424] transition-colors";

  return (
    <form id="checkoutForm" onSubmit={submit} className="grid lg:grid-cols-[1fr_380px] gap-8">
      <div className="space-y-8">
        {/* Shipping Info */}
        <div className="bg-[#FAF7F2]/70 p-6 rounded-2xl border border-[#D9C7AD]/60">
          <h3 className="font-serif text-xl text-[#242424] mb-5">معلومات التوصيل</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#242424] mb-1.5">الاسم الأول *</label>
              <input required value={form.firstName} onChange={set("firstName")} placeholder="مثال: سلمى" className={input} />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#242424] mb-1.5">اسم العائلة</label>
              <input value={form.lastName} onChange={set("lastName")} placeholder="المنصوري" className={input} />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#242424] mb-1.5">رقم الهاتف المغربي *</label>
              <input required value={form.phone} onChange={set("phone")} placeholder="06 XX XX XX XX" className={input} dir="ltr" />
              {form.phone && !phoneValid && <p className="text-xs text-red-600 mt-1">رقم هاتف مغربي غير صحيح.</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-[#242424] mb-1.5">البريد الإلكتروني (اختياري)</label>
              <input value={form.email} onChange={set("email")} type="email" placeholder="your@email.com" className={input} dir="ltr" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-[#242424] mb-1.5">العنوان الكامل *</label>
              <textarea required value={form.address} onChange={set("address")} rows={2} placeholder="الحي، الشارع، رقم الإقامة..." className={input} />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-[#242424] mb-1.5">المدينة *</label>
              <select value={form.city} onChange={set("city")} className={input}>
                {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* Payment */}
        <div className="bg-[#FAF7F2]/70 p-6 rounded-2xl border border-[#D9C7AD]/60">
          <h3 className="font-serif text-xl text-[#242424] mb-5">طريقة الدفع</h3>
          <div className="space-y-3">
            <label className="flex items-start gap-3 p-4 rounded-xl bg-[#FAF7F2] border-2 border-[#242424] cursor-pointer">
              <input type="radio" name="payment" defaultChecked className="mt-1 accent-[#242424]" />
              <div>
                <strong className="block text-sm text-[#242424]">الدفع عند الاستلام (COD)</strong>
                <span className="text-xs text-[#242424]/60">ادفعي نقداً عند استلام طردكِ. متاح لجميع مدن المغرب.</span>
              </div>
            </label>
            <label className="flex items-start gap-3 p-4 rounded-xl bg-[#F3EBDD]/50 border border-[#D9C7AD]/40 opacity-50 cursor-not-allowed">
              <input type="radio" name="payment" disabled className="mt-1" />
              <div>
                <strong className="block text-sm text-[#242424]">الدفع الإلكتروني</strong>
                <span className="text-xs text-[#242424]/60">معطّل حتى التحقق من مزود دفع مغربي (قريباً).</span>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* Order Summary */}
      <aside className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#D9C7AD]/60 h-fit sticky top-24">
        <h2 className="font-serif text-xl text-[#242424] mb-5">ملخص الطلب</h2>
        <div className="space-y-3 mb-4">
          {items.map((i) => {
            const prod = products.find((x) => x.slug === i.slug);
            return (
              <div key={i.productId} className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg overflow-hidden border border-[#D9C7AD]/60 shrink-0 bg-[#F3EBDD]">
                  {prod?.images[0] && <img src={prod.images[0]} alt={i.name} className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-[#242424] truncate">{i.name}</p>
                  <p className="text-[10px] text-[#242424]/60">× {i.qty}</p>
                </div>
                <span className="text-sm font-bold text-[#242424]">{formatMAD(i.price * i.qty, locale)}</span>
              </div>
            );
          })}
        </div>
        <div className="border-t border-[#D9C7AD]/60 pt-4 space-y-2 text-sm">
          <div className="flex justify-between"><span>المجموع الفرعي</span><span className="font-medium">{formatMAD(totals.subtotal, locale)}</span></div>
          <div className="flex justify-between text-[#242424]/60"><span>التوصيل</span><span>{shippingFee === 0 ? "مجاني (فوق 400 د.م)" : `${shippingFee} درهم`}</span></div>
          <div className="flex justify-between text-lg font-bold text-[#242424] pt-2 border-t border-[#D9C7AD]/60">
            <span>الإجمالي</span>
            <span className="font-serif">{formatMAD(finalTotal, locale)}</span>
          </div>
        </div>
        <button type="submit" form="checkoutForm" disabled={state === "loading" || !items.length} className="w-full mt-6 py-4 rounded-full bg-[#242424] text-[#FAF7F2] text-sm font-medium hover:bg-[#242424]/90 transition-all shadow-md disabled:opacity-40 disabled:pointer-events-none">
          {state === "loading" ? "جاري المعالجة..." : `تأكيد الطلب (${formatMAD(finalTotal, locale)})`}
        </button>
        <p className="text-[10px] text-[#242424]/50 text-center mt-3">لا يتم جمع أي بيانات بطاقة. الطلب يُنشأ بعد التحقق من الخادم.</p>
      </aside>
    </form>
  );
}
