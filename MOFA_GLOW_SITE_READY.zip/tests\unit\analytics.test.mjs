import test from "node:test";
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const a = await import(pathToFileURL("C:/Users/Mohamed Chraim/Downloads/CHRAIM_Campus_Final/apps/storefront/src/lib/analytics.ts").href);

test("catalog metrics are internally consistent", () => {
  const m = a.catalogMetrics();
  assert.equal(m.totalProducts, m.ownBrand + m.dropshipping);
  assert.ok(m.inStock <= m.totalProducts);
  assert.ok(m.averageMargin >= 0 && m.averageMargin <= 1);
  assert.ok(m.catalogValueMAD > 0);
});

test("formula documentation present", () => {
  assert.match(a.metricFormulas["Net order profit"], /shipping/);
});