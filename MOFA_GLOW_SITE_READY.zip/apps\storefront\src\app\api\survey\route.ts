import { NextResponse } from "next/server";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { getSupabase, isSupabaseConfigured } from "@/lib/supabase";
const getClient = () => getSupabase();

export async function POST(request: Request) {
  const gate = rateLimit(`${clientKey(request)}:survey`, 5, 60_000);
  if (!gate.allowed) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  let body: any;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "invalid_json" }, { status: 400 }); }

  // Honeypot check
  if (body.website) {
    return NextResponse.json({ message: "Thank you." });
  }

  if (!isSupabaseConfigured()) {
    return NextResponse.json({ error: "survey_backend_not_configured", message: "Survey is not connected yet. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY." }, { status: 503 });
  }

  try {
    const { error } = await getClient()!.from("mg_survey_responses").insert({
      age_range: body.ageRange || null,
      skin_type: body.skinType || null,
      concerns: body.concerns || [],
      budget_range: body.budgetRange || null,
      preferred_products: body.preferredProducts || [],
      email: body.email || null,
      locale: body.locale || "ar",
    });
    if (error) return NextResponse.json({ error: "submission_failed", message: error.message }, { status: 500 });
    return NextResponse.json({ message: "Thank you for your response." });
  } catch (err: any) {
    return NextResponse.json({ error: "submission_failed", message: err.message }, { status: 500 });
  }
}

