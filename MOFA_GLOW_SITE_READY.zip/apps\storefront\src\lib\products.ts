export type ProductSource = "OWN_BRAND" | "DROPSHIPPING";

export interface Product {
  id: string;
  sku: string;
  slug: string;
  name: string;
  nameFr: string;
  description: string;
  subtitle: string;
  category: string;
  categoryLabel: string;
  volume: string;
  price: number;
  cost: number;
  currency: "MAD";
  source: ProductSource;
  inStock: boolean;
  images: string[];
  badge: string;
  ingredients: string[];
  ritual: string;
  packagingDesc: string;
  estimatedDeliveryDays: number;
}

const MARGIN = 120;

// Local fallback products (used when Supabase is not configured)
export const localProducts: Product[] = [
  {
    id: "mofa-retinol-cream",
    sku: "MG-RET-100",
    slug: "retinol-night-cream",
    name: "كريم الريتينول الليلي المجدد",
    nameFr: "Crème Rétinol Régénérante",
    description: "يقلل التجاعيد والخطوط الدقيقة ويوحّد ملمس البشرة ويخفف البقع. تركيبة غنية بالريتينول المغلف مع حمض الهيالورونيك وفيتامين E.",
    subtitle: "يقلل التجاعيد والخطوط الدقيقة ويوحّد ملمس البشرة ويخفف البقع",
    category: "face",
    categoryLabel: "العناية بالوجه",
    volume: "100ml",
    price: 79 + MARGIN,
    cost: 79,
    currency: "MAD",
    source: "OWN_BRAND",
    inStock: true,
    images: [
      "/images/uploads/AvF8Ua33QZmsESJ05cEkjzkfegM9FZW9dxsTEC1r.webp",
      "/images/uploads/Gemini_Generated_Image_am0kuwam0kuwam0k000000.jfif",
    ],
    badge: "الأكثر طلباً",
    ingredients: ["ريتينول نقي مغلف (0.3%)", "حمض الهيالورونيك المرطب", "فيتامين E المضاد للأكسدة", "زيت اللوز الحلو"],
    ritual: "يُوضع مساءً على بشرة نظيفة وجافة مع التدليك بلطف بحركات دائرية صاعدة. يُنصح باستخدام واقي شمس صباحاً.",
    packagingDesc: "أنبوب عاجي غير لامع بغطاء ذهبي مصقول وشعار القطرة المضيئة MOFA GLOW",
    estimatedDeliveryDays: 2,
  },
  {
    id: "mofa-melasma-cream",
    sku: "MG-MEL-060",
    slug: "melasma-natural-cream",
    name: "كريم الكلف وتوحيد اللون الطبيعي",
    nameFr: "Crème Mélasma 100% Naturel",
    description: "تركيبة نباتية 100% لتفتيح التصبغات والبقع الداكنة والكلف. مستخلص عرق السوس، زيت الأرغان المغربي، فيتامين C.",
    subtitle: "تركيبة نباتية 100% لتفتيح التصبغات والبقع الداكنة والكلف",
    category: "specialized",
    categoryLabel: "علاجات متخصصة",
    volume: "60g",
    price: 85 + MARGIN,
    cost: 85,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/u55YX36J2aBgi9ip5ad5qi0Q6jLH4QKHFX56PNnK.webp",
      "/images/uploads/Gemini_Generated_Image_am0kuwam0kuwam0k666666666666.jfif",
    ],
    badge: "طبيعي 100%",
    ingredients: ["مستخلص عرق السوس النقي", "زيت الأرغان المغربي البكر", "فيتامين C المستقر", "شمع العسل الطبيعي"],
    ritual: "يُطبق صباحاً ومساءً على مناطق التصبغ والكلف مع تدليك خفيف حتى الامتصاص الكامل.",
    packagingDesc: "عبوة صيدلانية عاجية فاخرة بغطاء ذهبي مضلع وملصق بيج دافئ",
    estimatedDeliveryDays: 5,
  },
  {
    id: "mofa-teeth-powder",
    sku: "MG-DEN-050",
    slug: "natural-teeth-whitening-powder",
    name: "بودرة تبييض الأسنان النباتية",
    nameFr: "Poudre Blanchiment des Dents",
    description: "تبييض لطيف بالقرنفل والسواك الطبيعي لنفس منعش وإشراقة صحية. مسحوق السواك، خلاصة براعم القرنفل، كربونات الكالسيوم.",
    subtitle: "تبييض لطيف بالقرنفل والسواك الطبيعي لنفس منعش وإشراقة صحية",
    category: "personal",
    categoryLabel: "العناية الشخصية",
    volume: "50g",
    price: 59 + MARGIN,
    cost: 59,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/jPqmxARaye5i5JYjPOtO1zWkxsx3Gk44iJNCWMrm.webp",
      "/images/uploads/Gemini_Generated_Image_am0kuwam0kuwam0k111111111.jfif",
    ],
    badge: "طبيعي 100%",
    ingredients: ["مسحوق السواك الطبيعي", "خلاصة براعم القرنفل", "كربونات الكالسيوم الدقيقة", "نعناع أطلسي منعش"],
    ritual: "تُبلل فرشاة الأسنان وتُغمس بلطف في البودرة، تُفرّش الأسنان لمدة دقيقتين ثم تُشطف بالماء جيداً.",
    packagingDesc: "عبوة لؤلؤية محكمة الإغلاق بغطاء ذهبي مصقول للحفاظ على نقاء المسحوق النباتي",
    estimatedDeliveryDays: 6,
  },
  {
    id: "mofa-homme-virilite",
    sku: "MG-HOM-100",
    slug: "homme-vitality-cream",
    name: "كريم الحيوية والعناية للرجال",
    nameFr: "Crème de Virilité pour Hommes",
    description: "يحفز الدورة الدموية الدقيقة ويغذي البشرة ويمنح الثقة والأداء. مستخلص الجينسنغ، زيت الزنجبيل، فيتامين B5، زبدة الشيا.",
    subtitle: "يحفز الدورة الدموية الدقيقة ويغذي البشرة ويمنح الثقة والأداء",
    category: "men",
    categoryLabel: "إصدار الرجال",
    volume: "100g",
    price: 89 + MARGIN,
    cost: 89,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/HRdX0voTEDV0aEmhwKF7F3zxl5IQDdOGw8g6eqFB.webp",
      "/images/uploads/Gemini_Generated_Image_am0kuwam0kuwam0k444444.jfif",
    ],
    badge: "إصدار الرجال",
    ingredients: ["مستخلص الجينسنغ الأحمر", "زيت الزنجبيل المنشط", "فيتامين B5 المرمم", "زبدة الشيا النقية"],
    ritual: "تُوضع كمية مناسبة وتُدلك بلطف لمدة 3 إلى 5 دقائق حتى الامتصاص التام لتعزيز الحيوية والترطيب.",
    packagingDesc: "أنبوب عاجي فاخر بغطاء ذهبي برونزي من مجموعة العناية الرجالية MOFA GLOW",
    estimatedDeliveryDays: 3,
  },
  {
    id: "mofa-face-brightening",
    sku: "MG-ECL-050",
    slug: "face-brightening-cream",
    name: "كريم تفتيح وإشراقة الوجه",
    nameFr: "Crème Éclaircissement Visage",
    description: "بحمض الجليكوليك وزبدة الكاكاو وحمض اللاكتيك لإشراقة حريرية. تجديد خلايا لطيف وملمس مخملي مشرق.",
    subtitle: "بحمض الجليكوليك وزبدة الكاكاو وحمض اللاكتيك لإشراقة حريرية",
    category: "face",
    categoryLabel: "العناية بالوجه",
    volume: "50g",
    price: 75 + MARGIN,
    cost: 75,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/KgU9hoSXITmkp7jVUlr5TieuaOXxdJDmfuNF0OQ3.webp",
      "/images/uploads/Gemini_Generated_Image_am0kuwam0kuwam0k7777.jfif",
    ],
    badge: "إشراقة حريرية",
    ingredients: ["حمض الجليكوليك اللطيف", "زبدة الكاكاو الخام", "حمض اللاكتيك المرطب", "مستخلص البابونج"],
    ritual: "يُستخدم مساءً على بشرة نظيفة لتجديد الخلايا بلطف ومنح الوجه ملمساً مخملياً مشرقاً.",
    packagingDesc: "عبوة عاجية مصقولة بغطاء ذهبي مضلع وملصق طبيعي فاخر",
    estimatedDeliveryDays: 3,
  },
  {
    id: "mofa-joint-relief",
    sku: "MG-ART-100",
    slug: "joint-relief-cream",
    name: "كريم راحة المفاصل والعضلات",
    nameFr: "Crème Douleurs Articulaires",
    description: "يحفز الدورة الدموية ويخفف الالتهاب والتورم ويعزز استرخاء العضلات. زيت الكافور والأوكالبتوس، المنثول، أرنكا.",
    subtitle: "يحفز الدورة الدموية ويخفف الالتهاب والتورم ويعزز استرخاء العضلات",
    category: "personal",
    categoryLabel: "العناية الشخصية",
    volume: "100ml",
    price: 69 + MARGIN,
    cost: 69,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/lXwNiaPtTZnDw1tLy69NEJUEEaqjR5pWDgVO6qWD.webp",
      "/images/uploads/00000000.jfif",
    ],
    badge: "راحة فورية",
    ingredients: ["زيت الكافور والأوكالبتوس", "المنثول الطبيعي المبرد", "مستخلص زهرة العطاس (Arnica)", "زيت إكليل الجبل"],
    ritual: "يُدلك بلطف على منطقة المفاصل أو العضلات المجهدة مرتين يومياً بحركات دائرية لتعزيز الاسترخاء.",
    packagingDesc: "أنبوب علاجي حريري باللون العاجي الدافئ مصمم لسهولة التدليك والاستخدام اليومي",
    estimatedDeliveryDays: 4,
  },
  {
    id: "mofa-retinol-airless",
    sku: "MG-AIR-050",
    slug: "retinol-airless-serum",
    name: "إكسير الريتينول المركّز (Airless)",
    nameFr: "Crème Rétinole Haute Concentration",
    description: "يحفز إنتاج الكولاجين ويسرّع تجديد الخلايا ويقلل آثار الشمس والشيخوخة. مركب ريتينول مطور، ببتيدات، نيانسيناميد.",
    subtitle: "يحفز إنتاج الكولاجين ويسرّع تجديد الخلايا ويقلل آثار الشمس والشيخوخة",
    category: "face",
    categoryLabel: "العناية بالوجه",
    volume: "50ml",
    price: 95 + MARGIN,
    cost: 95,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/tyTTN8kfR6bxwvitlbY6VL1OZjKlnz3xtMJVCUzp.webp",
      "/images/uploads/8888.jfif",
    ],
    badge: "تركيبة مركزة",
    ingredients: ["مركب الريتينول المطور", "ببتيدات الكولاجين البحري", "النياسيناميد (فيتامين B3)", "سكوالان الزيتون"],
    ritual: "ضغطة واحدة تكفي لتوزيع الإكسير على الوجه والرقبة مساءً قبل كريم الترllib الليلي.",
    packagingDesc: "قارورة ضغاطة بتقنية Airless تحمي التركيبة من الأكسدة مع طوق ذهبي مصقول",
    estimatedDeliveryDays: 3,
  },
  {
    id: "mofa-vitiligo-care",
    sku: "MG-VIT-050",
    slug: "botanical-skin-balance-cream",
    name: "كريم العناية وتوازن لون البشرة",
    nameFr: "Vitiligo Cream Soin Botanique",
    description: "مستخلصات نباتية وفيتامينات لتغذية البشرة وتحسين تجانس مظهرها. حبة البركة، فيتامين D3/E، جينكة بيلوبا.",
    subtitle: "مستخلصات نباتية وفيتامينات لتغذية البشرة وتحسين تجانس مظهرها",
    category: "specialized",
    categoryLabel: "علاجات متخصصة",
    volume: "50g",
    price: 99 + MARGIN,
    cost: 99,
    currency: "MAD",
    source: "DROPSHIPPING",
    inStock: true,
    images: [
      "/images/uploads/HSk9oE8qkQHEU7ZHRmVUSTwvxvYkFHeTpWd3pcQd.webp",
      "/images/uploads/Gemini_Generated_Image_am0kuwam0kuwam0k.jfif",
    ],
    badge: "عناية متخصصة",
    ingredients: ["مستخلص حبة البركة النقي", "فيتامين D3 و E", "مستخلص الجنكة بيلوبا", "زيت جنين القمح"],
    ritual: "يُوضع مرتين يومياً على البشرة النظيفة والجافة مع تدليك لطيف لتغذية الخلايا ودعم توازن اللون.",
    packagingDesc: "عبوة فاخرة بلون الفحم الداكن لحماية المستخلصات النباتية من الضوء مع ملصق عاجي مذهب",
    estimatedDeliveryDays: 4,
  },
];

// Export products (local fallback or Supabase-fetched)
export const products: Product[] = localProducts;

export function getProductBySlug(slug: string) {
  return products.find((p) => p.slug === slug);
}

export function getProductById(id: string) {
  return products.find((p) => p.id === id);
}

export const categories = Array.from(new Set(products.map((p) => p.category)));

export const categoryLabels: Record<string, string> = {
  face: "العناية بالوجه",
  specialized: "علاجات متخصصة",
  personal: "العناية الشخصية",
  men: "إصدار الرجال",
};
