import { isLocale, getMessages } from "@/lib/i18n";
import PolicyLayout from "@/components/PolicyLayout";
import ContactForm from "@/components/ContactForm";

export default async function ContactPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <PolicyLayout locale={l} messages={m} title={m.nav.contact}>
      <p>For order questions, delivery issues or product enquiries, use the form below or reach us through the channels published on our official accounts.</p>
      <p>Please include your order reference when contacting us about an existing order. We do not collect more personal information than needed to answer your request.</p>
      <ContactForm />
    </PolicyLayout>
  );
}