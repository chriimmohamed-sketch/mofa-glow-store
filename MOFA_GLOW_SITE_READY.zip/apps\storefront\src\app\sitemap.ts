import type { MetadataRoute } from "next";
import { locales } from "@/lib/i18n";
import { products } from "@/lib/products";
export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "https://mofaglow.ma";
  const pages = ["", "/shop", "/categories", "/collections", "/about", "/philosophy", "/journal", "/contact", "/faq", "/launch", "/survey", "/track", "/shipping", "/returns", "/privacy", "/terms"];
  const out: MetadataRoute.Sitemap = [];
  for (const l of locales) { for (const p of pages) out.push({ url: `${base}/${l}${p}` }); for (const pr of products) out.push({ url: `${base}/${l}/product/${pr.slug}` }); }
  return out;
}