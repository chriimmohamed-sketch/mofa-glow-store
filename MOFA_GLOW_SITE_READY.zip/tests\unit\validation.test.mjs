import test from "node:test";
import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const v = await import(pathToFileURL("C:/Users/Mohamed Chraim/Downloads/CHRAIM_Campus_Final/apps/storefront/src/lib/validation.ts").href);

test("Moroccan phone formats", () => {
  assert.equal(v.isValidMoroccanPhone("0612345678"), true);
  assert.equal(v.isValidMoroccanPhone("+212612345678"), true);
  assert.equal(v.isValidMoroccanPhone("061 234 5678"), true);
  assert.equal(v.isValidMoroccanPhone("12345"), false);
});

test("email validation", () => {
  assert.equal(v.isValidEmail("a@b.ma"), true);
  assert.equal(v.isValidEmail("bad@"), false);
});

test("sanitizeText strips angle brackets", () => {
  assert.equal(v.sanitizeText("  <script>hello</script>  "), "scripthello/script");
});