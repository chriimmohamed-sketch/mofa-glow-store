import { catalogMetrics, metricFormulas } from "@/lib/analytics";
import { products } from "@/lib/products";
import { profitMargin } from "@/lib/money";
import MofaLogo from "@/components/MofaLogo";
import Link from "next/link";

export const metadata = { title: "Command Center" };

export default function AdminPage() {
  const m = catalogMetrics();
  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)]">
      <header className="border-b border-[var(--line)] bg-[var(--surface)]">
        <div className="container py-5 flex items-center justify-between">
          <MofaLogo />
          <div className="text-xs text-[var(--muted)]">COMMAND CENTER · PREVIEW</div>
        </div>
      </header>
      <main className="container py-12">
        <div className="eyebrow mb-3">EXECUTIVE OVERVIEW</div>
        <h1 className="font-display display-md mb-3">Business Command Center</h1>
        <p className="text-sm text-[var(--muted)] max-w-2xl mb-10">
          Catalogue intelligence computed server-side from the current curated concept range.
          Sales, revenue and net-profit analytics require a live WooCommerce connection and are intentionally not shown as numbers.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            ["Products", m.totalProducts.toString()],
            ["Own brand", m.ownBrand.toString()],
            ["Dropshipping", m.dropshipping.toString()],
            ["In stock", m.inStock.toString()],
            ["Avg. margin", `${(m.averageMargin * 100).toFixed(1)}%`],
            ["Avg. delivery", `${m.averageDeliveryDays.toFixed(1)} days`],
            ["Catalog value", `${m.catalogValueMAD.toFixed(0)} MAD`],
            ["Live orders", "NOT CONNECTED"],
          ].map(([label, value]) => (
            <div key={label} className="card p-5">
              <div className="eyebrow mb-2">{label}</div>
              <div className="font-display text-2xl">{value}</div>
            </div>
          ))}
        </div>

        <section className="mb-12">
          <h2 className="font-display text-2xl mb-5">Product performance</h2>
          <div className="card overflow-x-auto">
            <table className="w-full text-sm min-w-[640px]">
              <thead className="bg-[var(--surface-2)] text-left">
                <tr><th className="p-3">Product</th><th className="p-3">Source</th><th className="p-3">Price</th><th className="p-3">Margin</th><th className="p-3">Stock</th></tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id} className="border-t border-[var(--line)]">
                    <td className="p-3"><Link href={`/en/product/${p.slug}`} className="hover:text-[var(--accent)]">{p.name}</Link></td>
                    <td className="p-3">{p.source}</td>
                    <td className="p-3">{p.price} MAD</td>
                    <td className="p-3">{(profitMargin(p.price, p.cost) * 100).toFixed(1)}%</td>
                    <td className="p-3">{p.inStock ? "In stock" : "Out"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <div className="grid md:grid-cols-2 gap-6">
          <section className="card p-6">
            <h2 className="font-display text-xl mb-4">Financial formulas</h2>
            <ul className="space-y-2 text-sm text-[var(--muted)]">
              {Object.entries(metricFormulas).map(([k, v]) => <li key={k}><strong className="text-[var(--text)]">{k}:</strong> {v}</li>)}
            </ul>
          </section>
          <section className="card p-6">
            <h2 className="font-display text-xl mb-4">Integration health</h2>
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between"><span>WooCommerce</span><span className="text-[var(--accent)]">NOT VERIFIED</span></li>
              <li className="flex justify-between"><span>SpaceSeller</span><span className="text-[var(--accent)]">NOT VERIFIED</span></li>
              <li className="flex justify-between"><span>Online payment</span><span className="text-[var(--accent)]">DISABLED</span></li>
              <li className="flex justify-between"><span>Prod. deployment</span><span className="text-[var(--accent)]">PENDING</span></li>
            </ul>
            <p className="text-xs text-[var(--muted)] mt-4">No sync is claimed without confirmation from the external system.</p>
          </section>
        </div>
      </main>
    </div>
  );
}