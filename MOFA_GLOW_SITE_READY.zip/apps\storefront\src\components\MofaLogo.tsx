export default function MofaLogo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center" aria-label="MOFA GLOW" style={{ fontFamily: "'Amiri', serif", fontWeight: 700, letterSpacing: "1px" }}>
      <span className={compact ? "text-[1.15rem]" : "text-[1.5rem] md:text-[1.65rem]"}>MOFA GL</span>
      <span
        className="pearl glow-anim inline-block rounded-full mx-[1px] relative"
        style={{ width: compact ? 10 : 12, height: compact ? 10 : 12, top: 1 }}
        aria-hidden="true"
      />
      <span className={compact ? "text-[1.15rem]" : "text-[1.5rem] md:text-[1.65rem]"}>W</span>
    </span>
  );
}
