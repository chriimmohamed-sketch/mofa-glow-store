import test from "node:test"; import assert from "node:assert/strict"; import { pathToFileURL } from "node:url";
const m = await import(pathToFileURL("C:/Users/Mohamed Chraim/Downloads/CHRAIM_Campus_Final/apps/storefront/src/lib/money.ts").href);
test("formatMAD", () => assert.equal(m.formatMAD(100), "100.00 MAD"));
test("profitMargin", () => { assert.equal(m.profitMargin(200,100), .5); assert.equal(m.profitMargin(0,10), 0); });
test("netOrderProfit", () => assert.equal(m.netOrderProfit({ sales:1000, productCosts:400, shippingCosts:50, paymentFees:30, otherCosts:20 }), 500));