<?php
class MOFAGLOW_Sync_Log {
  public static function jobs_table() { global $wpdb; return $wpdb->prefix . 'mofaglow_sync_jobs'; }
  public static function logs_table() { global $wpdb; return $wpdb->prefix . 'mofaglow_sync_logs'; }
  public static function create_job( $type, $payload = array() ) { global $wpdb; $wpdb->insert( self::jobs_table(), array( 'job_type' => sanitize_key( $type ), 'status' => 'pending', 'payload' => wp_json_encode( $payload ) ) ); return $wpdb->insert_id; }
  public static function update_job( $id, $f ) { global $wpdb; $data = array(); foreach ( array( 'status', 'attempts', 'last_error', 'external_order_id' ) as $k ) if ( isset( $f[$k] ) ) $data[$k] = $f[$k]; return $wpdb->update( self::jobs_table(), $data, array( 'id' => (int) $id ) ); }
  public static function log( $job, $level, $message, $context = array() ) { global $wpdb; $wpdb->insert( self::logs_table(), array( 'job_id' => $job ? (int)$job : null, 'level' => $level, 'message' => sanitize_text_field( $message ), 'context' => wp_json_encode( $context ) ) ); }
  public static function jobs( $limit = 50 ) { global $wpdb; return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM " . self::jobs_table() . " ORDER BY created_at DESC LIMIT %d", $limit ) ); }
}