"use client";
import { useEffect, useState } from "react";
import { getLocalOrders, type LocalOrder } from "@/lib/orders";
import { formatMAD } from "@/lib/money";

const steps: LocalOrder["status"][] = ["pending", "processing", "shipped", "delivered"];

export default function OrdersClient({ locale }: { locale: string }) {
  const [orders, setOrders] = useState<LocalOrder[]>([]);
  useEffect(() => { setOrders(getLocalOrders()); }, []);
  const [open, setOpen] = useState<string | null>(null);

  if (!orders.length) {
    return <div className="card p-10 text-center text-[var(--muted)]">No orders on this device yet.</div>;
  }

  return (
    <div className="space-y-4">
      {orders.map((o) => (
        <div key={o.id} className="card p-6">
          <div className="flex flex-wrap justify-between gap-3 mb-4">
            <div>
              <div className="eyebrow">{new Date(o.createdAt).toLocaleDateString(locale)}</div>
              <div className="font-display text-xl mt-1">{o.id}</div>
            </div>
            <div className="text-end">
              <div className="price">{formatMAD(o.total, locale)}</div>
              <div className="text-xs text-[var(--muted)]">{o.payment === "cod" ? "Cash on delivery" : "Online"}</div>
            </div>
          </div>

          <div className="flex items-center gap-2 mb-4">
            {steps.map((s, i) => (
              <div key={s} className="flex-1">
                <div className={`h-1 ${i <= steps.indexOf(o.status) ? "bg-[var(--accent)]" : "bg-[var(--line)]"}`} />
                <div className="text-[.65rem] mt-1 text-[var(--muted)] capitalize">{s}</div>
              </div>
            ))}
          </div>

          <button type="button" onClick={() => setOpen(open === o.id ? null : o.id)} className="text-sm underline text-[var(--accent)]">
            {open === o.id ? "Hide details" : "View details"}
          </button>
          {open === o.id && (
            <div className="mt-4 border-t border-[var(--line)] pt-4 text-sm space-y-1">
              {o.items.map((i) => <div key={i.productId} className="flex justify-between"><span>{i.name} × {i.qty}</span><span>{formatMAD(i.price * i.qty, locale)}</span></div>)}
              <div className="text-[var(--muted)] pt-2">Shipping to {o.customer.city}, {o.customer.address}</div>
              <div className="text-xs text-[var(--accent)]">Local preview order — status updates require WooCommerce connection.</div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}