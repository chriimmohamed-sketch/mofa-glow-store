export function formatMAD(amount: number, locale: string = "ar") { return `${amount.toFixed(2)} MAD`; }
export function profitMargin(selling: number, cost: number) { return selling <= 0 ? 0 : (selling - cost) / selling; }
export function netOrderProfit(p: { sales: number; productCosts: number; shippingCosts: number; paymentFees: number; otherCosts: number }) {
  return p.sales - p.productCosts - p.shippingCosts - p.paymentFees - p.otherCosts;
}