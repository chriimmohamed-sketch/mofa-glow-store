import type { ReactNode } from "react";
import LocaleSync from "@/components/LocaleSync";
export default async function LocaleLayout({ children, params }: { children: ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  return <><LocaleSync locale={locale} />{children}</>;
}