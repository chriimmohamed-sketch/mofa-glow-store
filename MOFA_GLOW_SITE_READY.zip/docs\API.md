# API

Storefront: `/api/orders` (COD order creation via WooCommerce REST), `/api/survey` (forwards to WP REST `mofaglow/v1/survey` or `SURVEY_WEBHOOK_URL`). Both fail explicitly when unconfigured — no fake success.

Plugin REST namespace `mofaglow/v1`: `/suppliers`, `/spaceseller/test`, `/profit/product`, `/survey`.
