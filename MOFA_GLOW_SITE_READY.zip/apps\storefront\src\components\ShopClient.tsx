"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import type { Product } from "@/lib/products";
import { formatMAD } from "@/lib/money";
import WishlistButton from "@/components/WishlistButton";

export default function ShopClient({ products, locale, labels, initialCategory }: { products: Product[]; locale: string; labels: any; initialCategory?: string }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(initialCategory || "all");
  const [source, setSource] = useState("all");
  const [sort, setSort] = useState("featured");
  const cats = useMemo(() => ["all", ...Array.from(new Set(products.map((p) => p.category)))], [products]);
  const list = useMemo(() => {
    let r = products.filter((p) =>
      (!query || (p.name + p.description + p.sku).toLowerCase().includes(query.toLowerCase())) &&
      (category === "all" || p.category === category) &&
      (source === "all" || p.source === source)
    );
    if (sort === "price-asc") r = [...r].sort((a, b) => a.price - b.price);
    if (sort === "price-desc") r = [...r].sort((a, b) => b.price - a.price);
    if (sort === "name") r = [...r].sort((a, b) => a.name.localeCompare(b.name));
    return r;
  }, [products, query, category, source, sort]);

  const f = "field-input text-sm";
  return (
    <div>
      <div className="card p-4 md:p-5 mb-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={labels.search} className={f} />
        <select value={category} onChange={(e) => setCategory(e.target.value)} className={f}>
          {cats.map((c) => <option key={c} value={c}>{c === "all" ? labels.filter : c}</option>)}
        </select>
        <select value={source} onChange={(e) => setSource(e.target.value)} className={f}>
          <option value="all">Source</option>
          <option value="OWN_BRAND">OWN_BRAND</option>
          <option value="DROPSHIPPING">DROPSHIPPING</option>
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)} className={f}>
          <option value="featured">{labels.sort}</option>
          <option value="price-asc">Price: low → high</option>
          <option value="price-desc">Price: high → low</option>
          <option value="name">Name</option>
        </select>
      </div>

      <div className="flex items-center justify-between mb-6">
        <p className="text-sm text-[var(--muted)]">{list.length} results</p>
        {(query || category !== "all" || source !== "all" || sort !== "featured") && (
          <button type="button" onClick={() => { setQuery(""); setCategory("all"); setSource("all"); setSort("featured"); }} className="text-xs text-[var(--accent)] hover:underline">Clear filters</button>
        )}
      </div>

      {list.length === 0 ? (
        <div className="card p-14 text-center">
          <div className="font-display text-2xl mb-2">No results</div>
          <p className="text-sm text-[var(--muted)]">{labels.error || "Try adjusting your search or filters."}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 lg:gap-6">
          {list.map((p) => (
            <div key={p.id} className="card card-hover p-4 relative group">
              <div className="absolute top-3 start-3 z-10">
                <span className={`text-[.6rem] tracking-wider uppercase px-2 py-1 ${p.inStock ? "bg-[var(--surface)]/90 text-[var(--text)]" : "bg-[var(--dark)]/80 text-white"}`}>
                  {p.inStock ? labels.stock || "In stock" : labels.out || "Out"}
                </span>
              </div>
              <div className="absolute top-3 end-3 z-10"><WishlistButton productId={p.id} /></div>
              <Link href={`/${locale}/product/${p.slug}`}>
                <div className="media-frame aspect-[4/5] mb-4">
                  {p.images[0] ? <img src={p.images[0]} alt={p.name} loading="lazy" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center font-display text-5xl text-[var(--accent)]">{p.name.charAt(0)}</div>}
                </div>
                <div className="text-[.65rem] tracking-[.15em] uppercase text-[var(--muted)] mb-1">{p.category}</div>
                <div className="font-display text-lg mb-1 group-hover:text-[var(--accent)] transition-colors">{p.name}</div>
              </Link>
              <div className="flex items-center justify-between mt-1">
                <div className="price">{formatMAD(p.price, locale)}</div>
                <span className="text-[.65rem] text-[var(--muted)]">{p.source === "OWN_BRAND" ? "Own" : "Curated"}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}