"use client";
import { useState } from "react";

export default function Newsletter({ locale }: { locale: string }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, locale }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.message || d.error);
      setState("done"); setMessage(d.message || "Subscribed."); setEmail("");
    } catch (err: any) {
      setState("error"); setMessage(err.message);
    }
  }

  return (
    <section className="border-t border-[var(--line)] bg-[var(--surface)]">
      <div className="container py-20 grid lg:grid-cols-[1fr_1fr] gap-12 items-center">
        <div>
          <div className="eyebrow mb-4">THE GLOW LETTER</div>
          <h2 className="font-display display-md mb-4">Stay close to the beginning.</h2>
          <p className="text-[var(--muted)] leading-relaxed max-w-md">Brand news and thoughtful updates. No noise, no spam — only when there is something worth sharing.</p>
        </div>
        <div>
          <form onSubmit={submit} className="flex flex-col sm:flex-row gap-3">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              aria-label="Email address"
              className="field-input flex-1"
            />
            <button type="submit" disabled={state === "loading"} className="btn btn-primary whitespace-nowrap">
              {state === "loading" ? "..." : "Subscribe"}
            </button>
          </form>
          {message && <p className="text-sm mt-3 text-[var(--muted)]" role={state === "error" ? "alert" : "status"}>{message}</p>}
          <p className="text-xs text-[var(--muted)] mt-4">By subscribing you agree to receive occasional emails from MOFA GLOW. Unsubscribe anytime.</p>
        </div>
      </div>
    </section>
  );
}
