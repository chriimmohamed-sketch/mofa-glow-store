import { isLocale, getMessages } from "@/lib/i18n";
import PolicyLayout from "@/components/PolicyLayout";

export default async function JournalPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <PolicyLayout locale={l} messages={m} title="The Glow Journal">
      <p>This journal is reserved for carefully edited, factual content about beauty, care and our brand journey.</p>
      <p>No articles are published yet. We will add pieces only after their information has been reviewed for accuracy — especially anything touching ingredients, safety, or claims.</p>
      <p>If you would like to receive the first issue, you can subscribe through the newsletter section on the homepage. Subscription is optional and requires an explicit opt-in.</p>
    </PolicyLayout>
  );
}