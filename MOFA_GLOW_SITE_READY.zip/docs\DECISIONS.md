# Architecture Decision Records

## ADR-001 — Headless storefront vs. direct WooCommerce theme
Status: PROVISIONAL (revisit before production).

Context: The brief requires WooCommerce as commerce source of truth and warns against adopting headless for novelty.
Decision: Keep the Next.js headless storefront for the current phase because the independent brand experience,
three-language RTL/LTR routing, and the integration-adapter boundary are implemented here.
Trade-off: higher maintenance than a WooCommerce theme; plugin compatibility must be validated before launch.
Review trigger: when WooCommerce credentials and the SpaceSeller integration method are available, compare
total cost, plugin compatibility, and editorial requirements. If headless adds no measurable value, migrate
the storefront into WordPress/WooCommerce. This decision is NOT final.

## ADR-002 — Logo direction
Status: ADOPTED AS WORKING DIRECTION.

Context: Logo concepts define A — CLINIQUE, B — BLOOM, C — SIGNAL. Brief recommends developing B.
Decision: `MofaLogo.tsx` uses an abstract bloom/pearl mark derived from B, with A's clarity in typography.
No clinical or medical cues, no imitation of other brands. Final artwork must be approved by the owner.

## ADR-003 — Product data
Status: INTERIM.

Context: No live WooCommerce catalogue is available; the brief forbids presenting fake data as real.
Decision: Frontend catalogue is explicitly labelled "curated concept range inspired by the public SpaceSeller
catalogue". No sales figures, reviews, or best-seller labels are shown. Admin metrics are catalogue metrics,
not revenue. Replacement by WooCommerce data is required before selling.

## ADR-004 — External integrations
Status: ENFORCED.

No API endpoints are invented. SpaceSeller, payment providers, and shipping carriers remain NOT VERIFIED /
NOT CONFIGURED until official documentation and credentials are verified. All affected API routes fail
explicitly rather than simulating success.
