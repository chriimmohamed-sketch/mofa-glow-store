<?php
class MOFAGLOW_Profit {
  public static function product_profit( $s, $c ) { return round( (float) $s - (float) $c, 2 ); }
  public static function product_margin( $s, $c ) { $s = (float) $s; return $s <= 0 ? 0 : round( ( (float) $s - (float) $c ) / $s, 4 ); }
  public static function net_order_profit( $a ) { return round( (float)($a['sales']??0) - (float)($a['product_costs']??0) - (float)($a['shipping_costs']??0) - (float)($a['payment_fees']??0) - (float)($a['other_costs']??0), 2 ); }
  public static function format_mad( $a ) { return number_format( (float) $a, 2, '.', ',' ) . ' MAD'; }
}