"use client";
import { useEffect } from "react";
import { dirFor, isLocale } from "@/lib/i18n";
export default function LocaleSync({ locale }: { locale: string }) {
  useEffect(() => { if (isLocale(locale)) { document.documentElement.lang = locale; document.documentElement.dir = dirFor(locale); } }, [locale]);
  return null;
}