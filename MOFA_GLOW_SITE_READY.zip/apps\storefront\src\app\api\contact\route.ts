import { NextResponse } from "next/server";
import { rateLimit, clientKey } from "@/lib/rate-limit";
import { submitContactMessage } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/supabase";

export async function POST(request: Request) {
  const gate = rateLimit(`${clientKey(request)}:contact`, 5, 60_000);
  if (!gate.allowed) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  let body: any;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "invalid_json" }, { status: 400 }); }

  const name = String(body.name || "").trim();
  const email = String(body.email || "").trim();
  const message = String(body.message || "").trim();
  if (!name || message.length < 10) return NextResponse.json({ error: "invalid_input" }, { status: 400 });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return NextResponse.json({ error: "invalid_email" }, { status: 400 });

  if (!isSupabaseConfigured()) {
    return NextResponse.json({ error: "contact_backend_not_configured", message: "Messages are not connected yet. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY." }, { status: 503 });
  }

  const result = await submitContactMessage(name, email, message);
  if (!result.success) {
    return NextResponse.json({ error: "delivery_failed", message: result.error || "Could not send your message." }, { status: 500 });
  }
  return NextResponse.json({ message: "Your message was sent." });
}
