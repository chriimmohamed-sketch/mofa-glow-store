# Architecture

Headless hybrid commerce. Next.js (TS/Tailwind, ar/fr/en RTL) + WordPress/WooCommerce (source of truth) + `mofaglow-core` plugin for suppliers, product sources, margins, sync, logs, permissions. MySQL/MariaDB. Cloudflare Workers/DNS. No Vercel. No duplicated WooCommerce logic.
