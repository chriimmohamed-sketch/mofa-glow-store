-- MOFA GLOW - Supabase Schema
-- Run this in Supabase SQL Editor (Dashboard > SQL Editor > New Query)

-- Products table
CREATE TABLE IF NOT EXISTS mg_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  name_fr text,
  description text,
  subtitle text,
  category text NOT NULL,
  category_label text,
  volume text,
  price numeric(10,2) NOT NULL,
  cost numeric(10,2) NOT NULL,
  currency text NOT NULL DEFAULT 'MAD',
  source text NOT NULL DEFAULT 'OWN_BRAND',
  in_stock boolean NOT NULL DEFAULT true,
  images jsonb NOT NULL DEFAULT '[]',
  badge text,
  ingredients jsonb DEFAULT '[]',
  ritual text,
  packaging_desc text,
  estimated_delivery_days int DEFAULT 3,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Categories table
CREATE TABLE IF NOT EXISTS mg_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  name_fr text,
  description text,
  image_url text,
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Orders table
CREATE TABLE IF NOT EXISTS mg_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text UNIQUE NOT NULL,
  customer_first_name text NOT NULL,
  customer_last_name text,
  customer_phone text NOT NULL,
  customer_email text,
  customer_address text NOT NULL,
  customer_city text NOT NULL,
  payment_method text NOT NULL DEFAULT 'cod',
  subtotal numeric(10,2) NOT NULL,
  shipping_fee numeric(10,2) NOT NULL DEFAULT 0,
  total numeric(10,2) NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Order items table
CREATE TABLE IF NOT EXISTS mg_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES mg_orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES mg_products(id),
  product_name text NOT NULL,
  product_sku text,
  price numeric(10,2) NOT NULL,
  qty int NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Newsletter subscribers
CREATE TABLE IF NOT EXISTS mg_newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  locale text DEFAULT 'ar',
  created_at timestamptz DEFAULT now()
);

-- Contact messages
CREATE TABLE IF NOT EXISTS mg_contact_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Survey responses
CREATE TABLE IF NOT EXISTS mg_survey_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  age_range text,
  skin_type text,
  concerns jsonb DEFAULT '[]',
  budget_range text,
  preferred_products jsonb DEFAULT '[]',
  email text,
  locale text DEFAULT 'ar',
  created_at timestamptz DEFAULT now()
);

-- Audit logs
CREATE TABLE IF NOT EXISTS mg_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action text NOT NULL,
  entity_type text,
  entity_id text,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE mg_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE mg_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE mg_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE mg_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE mg_newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE mg_contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE mg_audit_logs ENABLE ROW LEVEL SECURITY;

-- Public read access for products and categories
CREATE POLICY "Public read products" ON mg_products FOR SELECT USING (true);
CREATE POLICY "Public read categories" ON mg_categories FOR SELECT USING (true);

-- Insert access for orders (anyone can create orders)
CREATE POLICY "Public insert orders" ON mg_orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Public insert order_items" ON mg_order_items FOR INSERT WITH CHECK (true);

-- Newsletter insert
CREATE POLICY "Public insert newsletter" ON mg_newsletter_subscribers FOR INSERT WITH CHECK (true);

-- Contact messages insert
CREATE POLICY "Public insert contact" ON mg_contact_messages FOR INSERT WITH CHECK (true);

-- Survey responses insert
CREATE POLICY "Public insert survey" ON mg_survey_responses FOR INSERT WITH CHECK (true);

-- Audit logs insert
CREATE POLICY "Public insert audit" ON mg_audit_logs FOR INSERT WITH CHECK (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_mg_products_category ON mg_products(category);
CREATE INDEX IF NOT EXISTS idx_mg_products_slug ON mg_products(slug);
CREATE INDEX IF NOT EXISTS idx_mg_orders_reference ON mg_orders(reference);
CREATE INDEX IF NOT EXISTS idx_mg_orders_status ON mg_orders(status);
CREATE INDEX IF NOT EXISTS idx_mg_order_items_order_id ON mg_order_items(order_id);

-- Seed categories
INSERT INTO mg_categories (slug, name, name_fr, sort_order) VALUES
  ('face', 'العناية بالوجه', 'Soin du Visage', 1),
  ('specialized', 'علاجات متخصصة', 'Soins Spécialisés', 2),
  ('personal', 'العناية الشخصية', 'Soin Personnel', 3),
  ('men', 'إصدار الرجال', 'Homme', 4)
ON CONFLICT (slug) DO NOTHING;
