# Payments

COD implemented (WooCommerce order, status on-hold). Online payment adapter disabled until a Moroccan provider (e.g. CMI, PayZone — not verified here) is selected, merchant account created, callbacks signature-verified and real transactions tested. Never store card data; never trust browser redirect.
