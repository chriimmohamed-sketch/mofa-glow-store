"use client";
import { useState } from "react";
import Link from "next/link";

const locales = ["ar", "fr", "en"] as const;

export default function MobileMenu({ locale, messages, to }: { locale: string; messages: any; to: (l: string) => string }) {
  const [open, setOpen] = useState(false);
  const n = messages.nav;
  const links = [
    [n.shop, `/${locale}/shop`],
    [n.categories, `/${locale}/categories`],
    [messages.footer.collections || "Collections", `/${locale}/collections`],
    [n.about, `/${locale}/about`],
    [messages.footer.philosophy || "Philosophy", `/${locale}/philosophy`],
    ["Journal", `/${locale}/journal`],
    [n.cart, `/${locale}/cart`],
    [n.account, `/${locale}/account`],
  ];
  return (
    <div className="md:hidden">
      <button type="button" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)} className="p-2 text-[var(--text)]">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          {open ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
        </svg>
      </button>
      {open && (
        <div className="absolute left-0 right-0 top-16 bg-[var(--bg)] border-b border-[var(--line)] shadow-lg">
          <nav className="container py-6 flex flex-col gap-4 text-sm">
            {links.map(([label, href]) => (
              <Link key={href} href={href} onClick={() => setOpen(false)} className="py-1 hover:text-[var(--accent)]">{label}</Link>
            ))}
            <div className="flex gap-2 pt-2 border-t border-[var(--line)]">
              {locales.map((l) => (
                <Link key={l} href={to(l)} onClick={() => setOpen(false)} className={`px-3 py-1.5 text-xs ${l === locale ? "bg-[var(--dark)] text-white" : "border border-[var(--line)]"}`}>{l.toUpperCase()}</Link>
              ))}
            </div>
          </nav>
        </div>
      )}
    </div>
  );
}
