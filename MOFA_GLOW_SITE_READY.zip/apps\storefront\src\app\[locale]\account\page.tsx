import { isLocale, getMessages } from "@/lib/i18n";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import OrdersClient from "@/components/OrdersClient";
import Link from "next/link";

export default async function AccountPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const l = isLocale(locale) ? locale : "ar";
  const m = await getMessages(l);
  return (
    <>
      <Header locale={l} messages={m} />
      <main className="container py-12">
        <div className="eyebrow mb-3">MY ACCOUNT</div>
        <h1 className="font-display display-md mb-8">{m.nav.account}</h1>
        <div className="grid md:grid-cols-[220px_1fr] gap-8">
          <aside className="space-y-2 text-sm">
            <div className="p-3 bg-[var(--surface)] border border-[var(--line)]">Order history</div>
            <Link href={`/${l}/wishlist`} className="block p-3 hover:text-[var(--accent)]">Wishlist</Link>
            <Link href={`/${l}/contact`} className="block p-3 hover:text-[var(--accent)]">Get help</Link>
          </aside>
          <section>
            <h2 className="font-display text-xl mb-5">Order history & tracking</h2>
            <OrdersClient locale={l} />
          </section>
        </div>
      </main>
      <Footer locale={l} messages={m} />
    </>
  );
}