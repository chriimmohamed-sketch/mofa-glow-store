# Testing

11 unit tests: money, cart math, coupons. Run `npm test` in apps/storefront. Build verified with `npm run build`. Integration/E2E and PHPUnit pending external services.
