import test from "node:test"; import assert from "node:assert/strict"; import { pathToFileURL } from "node:url";
const m = await import(pathToFileURL("C:/Users/Mohamed Chraim/Downloads/CHRAIM_Campus_Final/apps/storefront/src/lib/coupons.ts").href);
test("percent", () => { const r=m.validateCoupon("glow10",300); assert.equal(r.valid,true); assert.equal(r.discount,30); });
test("fixed", () => { const r=m.validateCoupon("WELCOME20",200); assert.equal(r.valid,true); assert.equal(r.discount,20); });
test("invalid", () => assert.equal(m.validateCoupon("NOPE",500).reason,"invalid_code"));
test("min", () => assert.equal(m.validateCoupon("GLOW10",50).reason,"min_subtotal"));