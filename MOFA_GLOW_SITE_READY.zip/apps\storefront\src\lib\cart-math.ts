export interface CartLine { productId: string; price: number; qty: number; }
export function lineTotal(line: CartLine) { return Math.round(line.price * line.qty * 100) / 100; }
export function cartTotals(lines: CartLine[], shipping = 0, discount = 0) {
  const subtotal = Math.round(lines.reduce((s, l) => s + lineTotal(l), 0) * 100) / 100;
  return { subtotal, shipping, discount, total: Math.max(0, Math.round((subtotal + shipping - discount) * 100) / 100) };
}